import hashlib,json,random,sys
from pathlib import Path
import pytest,torch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from engine import Model,Config,Tokenizer,optimizer,save_checkpoint,load_checkpoint,batch
from data_da import FAMILIES,make_case,canonical,completion,independent,solve,score,row_of,code_value
from train import learning_rate

def small_model():
    return Model(Config(vocab_size=288,dim=32,layers=2,heads=4,kv_heads=2,hidden=64,delta_key_dim=8,max_context=64,checkpoint_blocks=True))
@pytest.mark.parametrize('family',FAMILIES)
def test_independent_targets(family):
    rng=random.Random(891)
    for _ in range(40):
        c=make_case(rng,family,'iid');text=completion(c)
        row={'family':family,'case':c,'answer':None if family=='code_generation' else independent(c)}
        assert score(row,text)[0]
@pytest.mark.parametrize('bad',['import os','def solve(x):\n    return __import__("os").system("id")','def solve(x):\n    while True: pass','def solve(x):\n    return x**100000000'])
def test_no_arbitrary_python_execution(bad):
    with pytest.raises((ValueError,SyntaxError)):code_value(bad,1)
@pytest.mark.parametrize('lang',['ru','en'])
def test_lossless_tokenizer(lang):
    tok=Tokenizer.load(ROOT/'data/tokenizer.json')
    text='Вычисли: -3+5. 🌍\nОтвет:\n' if lang=='ru' else 'Compute -3+5. Ω\nAnswer:\n'
    assert tok.decode(tok.encode(text,bos=True,eos=True))==text

def test_no_prompt_loss_and_right_padding():
    rows=[{'tokens':[1,10,11,12,13,2],'prompt_tokens':4},{'tokens':[1,11,12,2],'prompt_tokens':2}]
    x,y=batch(rows)
    assert y.tolist()==[[-100,-100,-100,13,2],[-100,12,2,-100,-100]]
    assert x.tolist()==[[1,10,11,12,13],[1,11,12,0,0]]

def test_canonical_query_and_arithmetic_groups():
    c={'family':'memory_update','writes':[['a',1],['b',2],['a',3]],'query':'a'}
    assert canonical(c)==canonical({**c,'query':'b'})
    assert canonical({'family':'arithmetic','values':[5,8],'op':'+'})==canonical({'family':'arithmetic','values':[8,5],'op':'*'})

def test_data_group_disjointness_and_languages():
    groups={}
    for name in ['train','validation','iid','surface','extrapolation','counterfactual']:
        rows=[json.loads(s) for s in (ROOT/f'data/{name}.jsonl').read_text().splitlines()]
        groups[name]={r['group'] for r in rows}
        assert all(r['group']==canonical(r['case']) for r in rows)
        for f in {r['family'] for r in rows}:assert {r['lang'] for r in rows if r['family']==f}=={'ru','en'}
    names=list(groups)
    for i,a in enumerate(names):
        for b in names[i+1:]:assert not groups[a]&groups[b]

def test_data_hashes_and_eos():
    spec=json.loads((ROOT/'data/MANIFEST.json').read_text())
    tok=Tokenizer.load(ROOT/'data/tokenizer.json')
    for name,m in spec['files'].items():
        path=ROOT/f'data/{name}.jsonl';assert hashlib.sha256(path.read_bytes()).hexdigest()==m['sha256']
        rows=[json.loads(s) for s in path.read_text().splitlines()]
        for r in rows:
            assert r['tokens'][-1]==tok.EOS
            assert tok.encode(r['prompt'],bos=True)==r['tokens'][:r['prompt_tokens']]

def test_exact_resume_one_next_update(tmp_path):
    torch.set_num_threads(2);torch.manual_seed(991);random.seed(992);rng=random.Random(993)
    m=small_model().train();opt=optimizer(m,.0001)
    x=torch.tensor([[1,3,4,5,6,7]]);y=torch.tensor([[-100,-100,5,6,7,2]])
    def step(mm,oo):
        oo.zero_grad(set_to_none=True)
        loss=mm(x,y);loss.backward();oo.step();return float(loss.detach())
    step(m,opt);opt.zero_grad(set_to_none=True)
    save_checkpoint(tmp_path/'checkpoint',m,opt,rng,1,{'lr':.0001},{'fixture':True})
    expected_py=random.random();expected_sampler=rng.random();expected_torch=torch.rand(3)
    expected_loss=step(m,opt);expected={k:v.clone() for k,v in m.state_dict().items()}
    mm,oo,rr,state=load_checkpoint(tmp_path/'checkpoint');mm.train()
    assert state['step']==1 and random.random()==expected_py and rr.random()==expected_sampler
    assert torch.equal(torch.rand(3),expected_torch)
    assert step(mm,oo)==expected_loss
    assert all(torch.equal(expected[k],v) for k,v in mm.state_dict().items())
    assert all(torch.equal(opt.state_dict()['state'][i]['exp_avg'],v['exp_avg']) for i,v in oo.state_dict()['state'].items())

def test_schedule_fixed():
    c=json.loads((ROOT/'configs/preregistered.json').read_text())
    assert learning_rate(16,c)==c['lr']
    assert abs(learning_rate(256,c)-c['lr']*.25)<1e-12

def test_prompt_only_inference_has_no_solver():
    text=(ROOT/'src/infer.py').read_text()
    assert 'data_da' not in text and 'solve(' not in text
    assert 'def generate' in (ROOT/'src/engine.py').read_text()

def test_counterfactual_pairs_change_gold():
    rows=[json.loads(s) for s in (ROOT/'data/counterfactual.jsonl').read_text().splitlines()]
    assert len(rows)==32
    for a,b in zip(rows[::2],rows[1::2]):
        assert a['case']['writes']==b['case']['writes']
        assert a['answer']!=b['answer'] and a['pair_id']==b['pair_id']
