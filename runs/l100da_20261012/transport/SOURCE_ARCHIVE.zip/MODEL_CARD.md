# FlyGraph L100DA step256 model card

Experimental inherited100M architecture; own full-parameter continuation, not an instruction-tuned general assistant. Parent L100EC curriculum BF16. 100,028,328 parameters, original8192-token reversible tokenizer. Native FP32 weights and optimizer/RNG provided separately from BF16 inference export. See configs and manifests for identity.

Completed256 new local CPU AdamW updates on2048 sampled synthetic RU/EN memory/math/code/list/condition examples. Primary numeric IID criterion failed (2/80→6/80,95%paired-bootstrap interval -1.25..12.5pp). New formulations0/48; extrapolation0/48; memory both-correct0/16 pairs. It still answers5+8 incorrectly. Do not deploy as a reliable solver or claim superiority to Qwen3.5-0.8B. No new Qwen run or broad benchmark was conducted.

Inherited pretraining provenance is limited: L100EC original training dataset unavailable; no proof of zero inherited contamination. Available historical train/held groups were excluded as documented. One seed, before/after pilot, no matched causal control. All raw model predictions and negative results retained. Engineering tests and artifact integrity are not capability evidence.
