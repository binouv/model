"""Recompute paired statistics from all frozen raw outputs; no favorable filtering."""
import json,csv
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sets={label:[json.loads(s) for s in (ROOT/f'metrics/{label}_predictions.jsonl').read_text().splitlines()] for label in ['parent','native','bf16']}
assert all(len(rows)==224 for rows in sets.values())
assert [r['id'] for r in sets['parent']]==[r['id'] for r in sets['native']]==[r['id'] for r in sets['bf16']]
p,n=sets['parent'],sets['native']
idx=[i for i,r in enumerate(p) if r['split']=='iid' and r['family']!='code_generation']
delta=np.array([int(n[i]['correct'])-int(p[i]['correct']) for i in idx]);rng=np.random.default_rng(1210113)
boot=delta[rng.integers(0,len(idx),size=(10000,len(idx)))].mean(axis=1)*100
ci=np.quantile(boot,[.025,.975]).tolist();gain=float(delta.mean()*100)
summaries={label:json.loads((ROOT/f'metrics/{label}_SUMMARY.json').read_text()) for label in sets}
cf={label:doc['splits']['counterfactual']['both_correct'] for label,doc in summaries.items()}
result={'status':'completed_fixed_budget_pilot','candidate_updates':256,'primary_numeric_iid':{'parent_correct':sum(p[i]['correct'] for i in idx),'candidate_correct':sum(n[i]['correct'] for i in idx),'n':len(idx),'gain_percentage_points':gain,'paired_bootstrap_95_ci_pp':ci,'primary_gate_passed':gain>=5 and ci[0]>0 and cf['native']>=cf['parent']},'counterfactual_both_correct':cf,'all_frozen_prompts':224,'native_bf16_identical_token_sequences':sum(a['generated_ids']==b['generated_ids'] for a,b in zip(sets['native'],sets['bf16'])),'all_domains':{label:doc['splits'] for label,doc in summaries.items()},'overall_qwen_superiority_goal_achieved':False,'qwen_new_inference_performed':False,'broad_benchmark_performed':False,'publication_status':'saved_local_remote_pending'}
(ROOT/'metrics/COMPLETED_SUMMARY.json').write_text(json.dumps(result,indent=2))
with (ROOT/'metrics/SUMMARY.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['split','parent_correct','native_correct','bf16_correct','n'])
 for split in ['iid','surface','extrapolation','counterfactual']:w.writerow([split,*[summaries[k]['splits'][split]['correct'] for k in ['parent','native','bf16']],summaries['parent']['splits'][split]['n']])
print(json.dumps(result['primary_numeric_iid']))
