"""Inference path uses only the trained neural model, tokenizer and prompt."""
import argparse,json
from pathlib import Path
import torch
from safetensors.torch import load_file
from engine import Model,Config,Tokenizer,ROOT,generate,digest
p=argparse.ArgumentParser();p.add_argument('--weights',type=Path,required=True);p.add_argument('--prompt',required=True);p.add_argument('--sha256',required=True);p.add_argument('--max-new-tokens',type=int,default=96);a=p.parse_args()
if digest(a.weights)!=a.sha256:raise ValueError('Weight checksum mismatch')
torch.set_num_threads(4)
m=Model(Config());m.load_state_dict(load_file(str(a.weights)),strict=True);m.eval().requires_grad_(False)
print(json.dumps(generate(m,Tokenizer.load(ROOT/'data/tokenizer.json'),a.prompt,a.max_new_tokens),ensure_ascii=False))
