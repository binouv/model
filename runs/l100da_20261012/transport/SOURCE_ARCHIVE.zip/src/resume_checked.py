"""Refuse replay of completed runs or rollback into a newer existing training log."""
import argparse,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--parent',type=Path,required=True);a=p.parse_args()
c=json.loads((ROOT/'configs/preregistered.json').read_text());state=json.loads((a.checkpoint/'CHECKPOINT.json').read_text());step=state['completed_optimizer_steps']
if step>=c['updates']:
    print(json.dumps({'status':'already_completed_no_retraining','step':step,'new_optimizer_updates':0}));raise SystemExit(0)
log=ROOT/'metrics/train.jsonl'
if log.exists():
    lines=log.read_text().splitlines();last=json.loads(lines[-1])['step'] if lines else 0
    if last!=step:raise RuntimeError('Training log and checkpoint differ. Preserve current run and recover into an isolated directory, never overwrite later history.')
raise SystemExit(subprocess.call([sys.executable,str(ROOT/'src/train.py'),'--parent',str(a.parent),'--resume',str(a.checkpoint)]))
