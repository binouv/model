"""L100DA: fixed-budget, answer-only, verified multi-family warm-start training."""
from __future__ import annotations
import argparse,gc,hashlib,json,math,random,resource,time,os
from pathlib import Path
import torch
from safetensors.torch import load_file,save_file
from engine import ROOT,Model,Config,Tokenizer,atomic_json,digest,batch,optimizer,save_checkpoint,load_checkpoint

def learning_rate(step:int,c:dict)->float:
    if step<=c['warmup']:return c['lr']*step/c['warmup']
    u=(step-c['warmup'])/(c['updates']-c['warmup'])
    return c['lr']*(.25+.75*.5*(1+math.cos(math.pi*u)))
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--parent',type=Path,required=True);ap.add_argument('--resume',type=Path);args=ap.parse_args()
    torch.set_num_threads(4);torch.set_num_interop_threads(1)
    c=json.loads((ROOT/'configs/preregistered.json').read_text())
    ids={'data_manifest':digest(ROOT/'data/MANIFEST.json'),'tokenizer':digest(ROOT/'data/tokenizer.json'),'parent':digest(args.parent),'preregistration':digest(ROOT/'configs/preregistered.json'),'sources':{rel:digest(ROOT/rel) for rel in ['base/model.py','base/tokenizer.py','src/engine.py','src/data_da.py','src/train.py']}}
    if ids['parent']!=c['parent_sha256']:raise ValueError('Wrong parent bytes')
    data_manifest=json.loads((ROOT/'data/MANIFEST.json').read_text())
    for name,entry in data_manifest['files'].items():
        if digest(ROOT/f'data/{name}.jsonl')!=entry['sha256']:raise ValueError('Frozen data changed')
    rows=[json.loads(s) for s in (ROOT/'data/train.jsonl').read_text().splitlines()]
    pools={}
    for f in c['families']:
        for level in ['elementary','iid']:pools[f,level]=[r for r in rows if r['family']==f and r['level']==level]
    if args.resume:
        m,opt,rng,state=load_checkpoint(args.resume)
        if state['identities']!=ids or state['run_config']!=c:raise ValueError('Resume configuration/source/data changed')
        start=state['step']
    else:
        torch.manual_seed(c['initialization_seed']);random.seed(c['initialization_seed']);rng=random.Random(c['sampler_seed'])
        m=Model(Config());m.load_state_dict(load_file(str(args.parent)),strict=True);opt=optimizer(m,c['lr']);start=0
    m.train();m.requires_grad_(True)
    n=sum(p.numel() for p in m.parameters())
    if n!=c['parameters']:raise ValueError('Parameter count mismatch')
    t0=time.monotonic();seen=0;grad_seen=set();losses=[]
    log_path=ROOT/'metrics/train.jsonl'
    if start==0 and log_path.exists():raise FileExistsError('Never silently restart an existing run')
    with log_path.open('a') as log:
        for step in range(start+1,c['updates']+1):
            picked=[]
            for j in range(c['batch']):
                family=c['families'][((step-1)*c['batch']+j)%len(c['families'])]
                level='elementary' if step<=c['elementary_updates'] or rng.random()<.25 else 'iid'
                picked.append(rng.choice(pools[family,level]))
            picked.sort(key=lambda r:len(r['tokens']))
            opt.zero_grad(set_to_none=True)
            supervised=sum(len(r['tokens'])-r['prompt_tokens'] for r in picked)
            n_input=0;value=0.
            lr=learning_rate(step,c)
            for pg in opt.param_groups:pg['lr']=lr
            for offset in range(0,len(picked),c['microbatch']):
                x,y=batch(picked[offset:offset+c['microbatch']]);n_input+=int(x.numel())
                weight=int(y.ne(-100).sum())/supervised
                with torch.autocast('cpu',dtype=torch.bfloat16):loss=m(x,y)*weight
                if not bool(torch.isfinite(loss)):raise FloatingPointError('Nonfinite loss')
                loss.backward();value+=float(loss.detach())
            for name,p in m.named_parameters():
                if p.grad is not None and bool(p.grad.abs().max()>0):grad_seen.add(name)
            grad_norm=torch.nn.utils.clip_grad_norm_(m.parameters(),1.0,error_if_nonfinite=True)
            opt.step();losses.append(value);seen+=supervised
            record={'step':step,'loss':value,'lr':lr,'gradient_norm_before_clip':float(grad_norm),'supervised_tokens':supervised,'input_tokens':n_input,'batch_ids_sha256':hashlib.sha256('|'.join(r['id'] for r in picked).encode()).hexdigest(),'elapsed_seconds':time.monotonic()-t0,'maxrss_kb':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
            log.write(json.dumps(record)+'\n');log.flush()
            if step%16==0:print(json.dumps(record),flush=True)
            if step%c['save_every']==0 or step==c['updates']:
                opt.zero_grad(set_to_none=True);gc.collect()
                receipt=save_checkpoint(ROOT/f'checkpoints/step_{step:04d}',m,opt,rng,step,c,ids)
                atomic_json(ROOT/'reports/RECOVERY_STATE.json',receipt)
                print(json.dumps({'checkpoint':step,'status':receipt['status']}),flush=True)
    final=ROOT/f'checkpoints/step_{c["updates"]:04d}'
    bf16={k:v.detach().to(torch.bfloat16).contiguous() for k,v in m.state_dict().items()}
    temporary=final/'model.bf16.safetensors.tmp'
    save_file(bf16,str(temporary));del bf16
    with temporary.open('rb') as handle:os.fsync(handle.fileno())
    os.replace(temporary,final/'model.bf16.safetensors')
    atomic_json(ROOT/'metrics/TRAINING_COMPLETED.json',{'status':'training_completed_evaluation_pending','new_optimizer_steps':c['updates']-start,'global_step':c['updates'],'parameters':n,'trainable_parameters':n,'parameter_tensors':len(list(m.parameters())),'parameter_tensors_with_nonzero_task_gradient':len(grad_seen),'seen_supervised_tokens_this_segment':seen,'loss_first16_mean':sum(losses[:16])/min(16,len(losses)),'loss_last16_mean':sum(losses[-16:])/min(16,len(losses)),'seconds':time.monotonic()-t0,'warm_start':not bool(args.resume),'bf16_sha256':digest(final/'model.bf16.safetensors'),'goal_achieved':False})
if __name__=='__main__':main()
