"""Deterministic offline verified tasks. No solver is imported by inference."""
from __future__ import annotations
import ast, hashlib, json, random, re
from pathlib import Path
FAMILIES=('arithmetic','conditional','code_trace','list_reasoning','memory_update','code_generation')
def sha_bytes(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def canonical(c:dict)->str:
    f=c['family']
    if f in ('arithmetic','list_reasoning'):
        obj={'family':f,'values':sorted(c['values'])}
    elif f=='memory_update':
        obj={'family':f,'histories':{k:[v for kk,v in c['writes'] if kk==k] for k in sorted({k for k,_ in c['writes']})}}
    elif f=='code_generation':
        a,b=1,0
        for op,v in c['program']:
            if op=='+':b+=v
            elif op=='-':b-=v
            else:a*=v;b*=v
        obj={'family':f,'affine':[a,b]}
    else:obj=c
    return sha_bytes(json.dumps(obj,sort_keys=True,separators=(',',':')).encode())
def solve(c:dict):
    f=c['family']
    if f=='arithmetic':
        a,b=c['values'];return a+b if c['op']=='+' else a-b if c['op']=='-' else a*b
    if f=='conditional':
        x,k,a,b=c['values'];return x+a if x<k else x-b
    if f in ('code_trace','code_generation'):
        x=c.get('start',0)
        for op,v in c['program']:x=x+v if op=='+' else x-v if op=='-' else x*v
        return x
    if f=='list_reasoning':return {'sum':sum,'min':min,'max':max}[c['kind']](c['values'])
    state={}
    for k,v in c['writes']:state[k]=v
    return state[c['query']]
def independent(c:dict):
    f=c['family']
    if f=='arithmetic':
        a,b=c['values']
        if c['op']=='*':return sum(a for _ in range(b))
        return sum((a,b if c['op']=='+' else -b))
    if f=='conditional':
        x,k,a,b=c['values'];return sum((x, a if x-k<0 else -b))
    if f=='code_trace':return sum([c['start']]+[v if op=='+' else -v for op,v in c['program']])
    if f=='list_reasoning':
        values=sorted(c['values'])
        if c['kind']=='min':return values[0]
        if c['kind']=='max':return values[-1]
        total=0
        for x in values:total+=x
        return total
    if f=='memory_update':return next(v for k,v in reversed(c['writes']) if k==c['query'])
    return None

def make_case(r:random.Random,f:str,level:str):
    high={'elementary':20,'iid':99,'ood':199}[level]
    low=100 if level=='ood' else 0
    n=4 if level=='ood' else 2
    if f=='arithmetic':
        op=r.choice('+-*');limit=14 if op=='*' and level!='ood' else high
        return {'family':f,'op':op,'values':[r.randint(low,limit),r.randint(low,limit)]}
    if f=='conditional':return {'family':f,'values':[r.randint(low,high) for _ in range(4)]}
    if f=='code_trace':return {'family':f,'start':r.randint(low,high),'program':[[r.choice('+-'),r.randint(1,9 if level=='elementary' else 20)] for _ in range(n)]}
    if f=='code_generation':return {'family':f,'program':[[r.choice('+-*'),r.randint(1,20 if level=='ood' else 9)] for _ in range(4 if level=='ood' else 3)]}
    if f=='list_reasoning':return {'family':f,'values':[r.randint(low,high) for _ in range(n+1)],'kind':r.choice(['sum','min','max'])}
    keys=list('abcd');writes=[[k,r.randint(low,high)] for k in keys]
    writes += [[r.choice(keys),r.randint(low,high)] for _ in range(8 if level=='ood' else 3)]
    r.shuffle(writes)
    return {'family':f,'writes':writes,'query':r.choice(keys)}

def render(c:dict,lang:str,variant:int=0)->str:
    ru=lang=='ru';f=c['family']
    if f=='arithmetic':
        a,b=c['values'];expr=f'{a} {c["op"]} {b}'
        text=(f'Вычисли: {expr}.' if ru else f'Calculate: {expr}.') if not variant else (f'Чему равно {expr}?' if ru else f'What is the value of {expr}?')
    elif f=='conditional':
        x,k,a,b=c['values']
        text=(f'x={x}. Если x<{k}, прибавь {a}, иначе вычти {b}.' if ru else f'x={x}. If x<{k}, add {a}; else subtract {b}.') if not variant else (f'Начни с {x}. Ниже {k}: +{a}. Иначе: -{b}.' if ru else f'Start at {x}. Below {k}: +{a}. Otherwise: -{b}.')
    elif f=='code_trace':
        code=f'x = {c["start"]}\n'+''.join(f'x {op}= {v}\n' for op,v in c['program'])+'print(x)'
        text=(('Что напечатает код?\n' if ru else 'What does this code print?\n') if not variant else ('Определи вывод:\n' if ru else 'Determine the output:\n'))+code
    elif f=='list_reasoning':
        word=({'sum':'сумма','min':'минимум','max':'максимум'} if ru else {'sum':'sum','min':'minimum','max':'maximum'})[c['kind']]
        text=(f'{c["values"]}. Найди: {word}.' if ru else f'Find the {word} of {c["values"]}.') if not variant else (f'Числа: {c["values"]}. Требуется {word}.' if ru else f'Numbers: {c["values"]}. Return their {word}.')
    elif f=='memory_update':
        w='; '.join(f'{k}={v}' for k,v in c['writes'])
        text=(f'Записи по времени: {w}. Последнее значение {c["query"]}?' if ru else f'Writes in time order: {w}. Latest value of {c["query"]}?') if not variant else (f'Обновления: {w}. Прочитай {c["query"]}.' if ru else f'Apply updates chronologically: {w}. Read {c["query"]}.')
    else:
        names=({'+' : 'прибавь','-':'вычти','*':'умножь на'} if ru else {'+':'add','-':'subtract','*':'multiply by'})
        actions='; '.join(f'{names[op]} {v}' for op,v in c['program'])
        text=(f'Напиши Python-функцию solve(x). По порядку: {actions}. Верни результат. Только код.' if ru else f'Write a Python function solve(x). In order: {actions}. Return the result. Code only.') if not variant else (f'Реализуй solve(x) на Python: {actions}. Возврати конечное x, только код.' if ru else f'Implement solve(x) in Python: {actions}. Return final x, code only.')
    return text+'\n'+('Ответ:\n' if ru else 'Answer:\n')

def completion(c:dict)->str:
    if c['family']!='code_generation':
        answer=solve(c)
        if answer!=independent(c):raise ValueError('Independent verifier disagrees')
        return f'F={answer}'
    return 'def solve(x):\n'+''.join(f'    x {op}= {v}\n' for op,v in c['program'])+'    return x'

def code_value(text:str,x:int)->int:
    """Bounded AST interpreter, never Python exec/eval or external tools."""
    if len(text)>12000:raise ValueError('Oversized code')
    text=text.strip()
    if text.startswith('```'):
        text=re.sub(r'^```(?:python)?\s*','',text);text=re.sub(r'\s*```$','',text)
    tree=ast.parse(text)
    if len(list(ast.walk(tree)))>256 or len(tree.body)!=1 or not isinstance(tree.body[0],ast.FunctionDef):raise ValueError('Expected one function')
    fun=tree.body[0]
    if fun.name!='solve' or [a.arg for a in fun.args.args]!=['x'] or fun.decorator_list or fun.args.defaults or fun.args.vararg or fun.args.kwarg or fun.args.kwonlyargs:raise ValueError('Invalid function signature')
    def expr(n,depth=0):
        if depth>32:raise ValueError('Expression too deep')
        if isinstance(n,ast.Name) and n.id=='x':return x
        if isinstance(n,ast.Constant) and type(n.value) is int and abs(n.value)<10**9:return n.value
        if isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.USub,ast.UAdd)):return -expr(n.operand,depth+1) if isinstance(n.op,ast.USub) else expr(n.operand,depth+1)
        if isinstance(n,ast.BinOp) and isinstance(n.op,(ast.Add,ast.Sub,ast.Mult)):
            a,b=expr(n.left,depth+1),expr(n.right,depth+1)
            z=a+b if isinstance(n.op,ast.Add) else a-b if isinstance(n.op,ast.Sub) else a*b
            if abs(z)>10**18:raise ValueError('Overflow guard')
            return z
        raise ValueError('Unsupported code expression')
    for stmt in fun.body:
        if isinstance(stmt,ast.Return):return expr(stmt.value)
        if isinstance(stmt,ast.Assign) and len(stmt.targets)==1 and isinstance(stmt.targets[0],ast.Name) and stmt.targets[0].id=='x':x=expr(stmt.value)
        elif isinstance(stmt,ast.AugAssign) and isinstance(stmt.target,ast.Name) and stmt.target.id=='x' and isinstance(stmt.op,(ast.Add,ast.Sub,ast.Mult)):
            v=expr(stmt.value);x=x+v if isinstance(stmt.op,ast.Add) else x-v if isinstance(stmt.op,ast.Sub) else x*v
            if abs(x)>10**18:raise ValueError('Overflow guard')
        else:raise ValueError('Unsupported statement')
    raise ValueError('No return')

def score(row:dict,text:str)->tuple[bool,str]:
    if row['family']=='code_generation':
        try:
            for x in [-31,-7,-1,0,1,9,37]:
                expected=x
                for op,v in row['case']['program']:expected=expected+v if op=='+' else expected-v if op=='-' else expected*v
                if code_value(text,x)!=expected:return False,'code_value_mismatch'
            return True,'seven_code_inputs_passed'
        except (ValueError,SyntaxError,TypeError,RecursionError,OverflowError):return False,'unsupported_or_invalid_code'
    hits=re.findall(r'(?:F|Ф)\s*=\s*(-?\d+)',text)
    if hits:return int(hits[-1])==row['answer'],'last_F_integer'
    if re.fullmatch(r'\s*-?\d+\s*',text):return int(text)==row['answer'],'bare_integer'
    return False,'no_unambiguous_final_integer'

def row_of(c:dict,lang:str,variant:int,tok,pair_id=None):
    prompt=render(c,lang,variant);target=completion(c);pids=tok.encode(prompt,bos=True)
    ids=tok.encode(prompt+target,bos=True,eos=True)
    if ids[:len(pids)]!=pids:raise ValueError('Token boundary changed')
    return {'id':sha_bytes((prompt+target).encode()),'group':canonical(c),'family':c['family'],'lang':lang,'case':c,'prompt':prompt,'completion':target,'answer':None if c['family']=='code_generation' else solve(c),'tokens':ids,'prompt_tokens':len(pids),'pair_id':pair_id}

def prepare(root:Path,tok,historical:Path):
    old_all=set();old_held=set()
    for path in historical.glob('*.jsonl'):
        for line in path.read_text().splitlines():
            z=json.loads(line)
            if 'case' in z:
                g=canonical(z['case']);old_all.add(g)
                if any(k in path.name for k in ['test','validation','probe']):old_held.add(g)
    r=random.Random(1210101);train=[];train_groups=set()
    # Repetition within train is allowed and measured. No inherited held group is used.
    for i in range(8192):
        f=FAMILIES[i%6];level='elementary' if i<2048 else 'iid'
        for _ in range(100000):
            c=make_case(r,f,level);g=canonical(c)
            if g not in old_held:break
        else:raise RuntimeError('Training group space exhausted')
        # Alternate language independent of family (six is even).
        z=row_of(c,'ru' if (i//6)%2 else 'en',0,tok)
        if len(z['tokens'])>384:raise ValueError('Training length limit, do not silently drop')
        z['level']=level;train.append(z);train_groups.add(g)
    occupied=old_all|train_groups;held={}
    for split,per,level,var,seed in [('iid',16,'iid',0,1210102),('surface',8,'iid',1,1210103),('extrapolation',8,'ood',0,1210104)]:
        r=random.Random(seed);rows=[]
        for f in FAMILIES:
            for i in range(per):
                for _ in range(100000):
                    c=make_case(r,f,level);g=canonical(c)
                    if g not in occupied:break
                else:raise RuntimeError('Held group space exhausted')
                occupied.add(g);rows.append(row_of(c,'ru' if i%2 else 'en',var,tok))
        held[split]=rows
    r=random.Random(1210105);pairs=[]
    for i in range(16):
        while True:
            c=make_case(r,'memory_update','iid');g=canonical(c)
            if g in occupied:continue
            alt=json.loads(json.dumps(c));alt['query']=r.choice([k for k in 'abcd' if k!=c['query']])
            if solve(c)!=solve(alt):break
        occupied.add(g)
        for cc in [c,alt]:pairs.append(row_of(cc,'ru' if i%2 else 'en',0,tok,f'da-cf-{i}'))
    held['counterfactual']=pairs
    val=[];r=random.Random(1210106)
    for i in range(96):
        while True:
            c=make_case(r,FAMILIES[i%6],'iid');g=canonical(c)
            if g not in occupied:break
        occupied.add(g);val.append(row_of(c,'ru' if (i//6)%2 else 'en',0,tok))
    files={'train':train,'validation':val,**held};manifest={}
    for name,rows in files.items():
        raw=''.join(json.dumps(z,ensure_ascii=False,separators=(',',':'))+'\n' for z in rows).encode()
        (root/'data'/f'{name}.jsonl').write_bytes(raw)
        manifest[name]={'sha256':sha_bytes(raw),'examples':len(rows),'canonical_groups':len({x['group'] for x in rows}),'max_tokens':max(len(x['tokens']) for x in rows)}
    output={'files':manifest,'historical_available_groups':len(old_all),'historical_held_groups_excluded_from_train':len(old_held),'new_held_overlap_with_available_historical':0,'new_held_overlap_with_train':0,'train_can_reuse_historical_train_groups':True,'unavailable_EC_original_train_decontamination':False,'same_family_and_template_limitations':True,'offline_verifier_only':True}
    (root/'data/MANIFEST.json').write_text(json.dumps(output,indent=2))
    return output
