"""Full-backbone trainer utilities with atomic, exact local resume checkpoints."""
from __future__ import annotations
import gc, hashlib, json, os, random, sys
from pathlib import Path
import torch
from safetensors.torch import load_file,save_file
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'base'))
from model import Config,Model
from tokenizer import Tokenizer

def digest(p:Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(4<<20),b''):h.update(b)
    return h.hexdigest()
def atomic_json(p:Path,obj)->None:
    tmp=p.with_name(p.name+'.tmp')
    with tmp.open('w',encoding='utf-8') as f:
        json.dump(obj,f,indent=2,ensure_ascii=False);f.flush();os.fsync(f.fileno())
    os.replace(tmp,p)
def batch(rows:list[dict]):
    length=max(len(r['tokens'])-1 for r in rows)
    x=torch.zeros(len(rows),length,dtype=torch.long);y=torch.full_like(x,-100)
    for i,r in enumerate(rows):
        seq=r['tokens'];x[i,:len(seq)-1]=torch.tensor(seq[:-1])
        y[i,r['prompt_tokens']-1:len(seq)-1]=torch.tensor(seq[r['prompt_tokens']:])
    return x,y

def optimizer(m,lr:float):return torch.optim.AdamW(m.parameters(),lr=lr,betas=(.9,.95),weight_decay=.01,foreach=False)
def rng_state(sampler:random.Random)->dict:
    return {'python':random.getstate(),'torch':torch.get_rng_state(),'sampler':sampler.getstate(),'cuda':torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None}
def restore_rng(state:dict,sampler:random.Random)->None:
    random.setstate(state['python']);torch.set_rng_state(state['torch']);sampler.setstate(state['sampler'])
    if state['cuda'] is not None and torch.cuda.is_available():torch.cuda.set_rng_state_all(state['cuda'])

def save_checkpoint(path:Path,m:Model,opt,sampler:random.Random,step:int,config:dict,identities:dict)->dict:
    if path.exists():raise FileExistsError(str(path))
    tmp=path.with_name(path.name+'.tmp');tmp.mkdir(parents=True,exist_ok=False)
    save_file({k:v.detach().cpu().contiguous() for k,v in m.state_dict().items()},str(tmp/'model.safetensors'))
    state={'optimizer':opt.state_dict(),'rng':rng_state(sampler),'step':step,'model_config':vars(m.config),'run_config':config,'identities':identities,'numpy_rng_used':False,'gradient_accumulation_pending':False,'grad_scaler':None,'scheduler':'deterministic formula of run_config and step'}
    torch.save(state,tmp/'training_state.pt')
    atomic_json(tmp/'config.json',vars(m.config))
    files={p.name:{'sha256':digest(p),'bytes':p.stat().st_size} for p in tmp.iterdir() if p.is_file()}
    for p in tmp.iterdir():
        if p.is_file():
            with p.open('rb') as f:os.fsync(f.fileno())
    # Metadata/key/shape inspection in a fresh object without duplicating RAM.
    loaded=load_file(str(tmp/'model.safetensors'))
    with torch.device('meta'):probe=Model(Config(**vars(m.config)))
    probe.load_state_dict(loaded,strict=True,assign=True)
    if not all(bool(torch.isfinite(v).all()) for v in loaded.values()):raise ValueError('Nonfinite checkpoint')
    del probe,loaded;gc.collect()
    state_probe=torch.load(tmp/'training_state.pt',weights_only=True,mmap=True)
    if state_probe['step']!=step or state_probe['identities']!=identities:raise ValueError('Training-state reload failed')
    del state_probe
    receipt={'status':'saved_local_verified','completed_optimizer_steps':step,'files':files,'native_weights_dtype':'FP32','parameters':sum(p.numel() for p in m.parameters()),'training_state_saved':True,'remote_publication':'pending','is_completed_scientific_result':False}
    atomic_json(tmp/'CHECKPOINT.json',receipt);os.replace(tmp,path)
    fd=os.open(path.parent,os.O_RDONLY)
    try:os.fsync(fd)
    finally:os.close(fd)
    return receipt

def load_checkpoint(path:Path):
    manifest=json.loads((path/'CHECKPOINT.json').read_text())
    for name,entry in manifest['files'].items():
        p=path/name
        if p.stat().st_size!=entry['bytes'] or digest(p)!=entry['sha256']:raise ValueError('Checkpoint integrity mismatch')
    state=torch.load(path/'training_state.pt',weights_only=True,mmap=True)
    m=Model(Config(**state['model_config']))
    m.load_state_dict(load_file(str(path/'model.safetensors')),strict=True)
    opt=optimizer(m,state['run_config']['lr']);opt.load_state_dict(state['optimizer'])
    sampler=random.Random();restore_rng(state['rng'],sampler)
    return m,opt,sampler,state

@torch.inference_mode()
def generate(m:Model,tok:Tokenizer,prompt:str,budget:int=96)->dict:
    ids=torch.tensor([tok.encode(prompt,bos=True)])
    if len(ids[0])+budget>m.config.max_context:raise ValueError('Input/output budget exceeds context')
    with torch.autocast('cpu',dtype=torch.bfloat16):seq=m.generate(ids,max_new_tokens=budget,eos_id=tok.EOS)[0].tolist()
    eos=tok.EOS in seq;visible=seq[:seq.index(tok.EOS)] if eos else seq
    return {'completion':tok.decode(visible),'generated_ids':seq,'generated_tokens':len(seq),'eos':eos,'stop_reason':'eos' if eos else 'length','inference_input':'prompt_only','tools_used':False}
