"""Frozen prompt-only generation; targets are used solely by offline scoring."""
from __future__ import annotations
import argparse,collections,json,time
from pathlib import Path
import torch
from safetensors.torch import load_file
from engine import ROOT,Model,Config,Tokenizer,generate,digest,atomic_json
from data_da import score

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--weights',type=Path,required=True);ap.add_argument('--label',required=True);args=ap.parse_args()
    if not args.label.replace('_','').isalnum():raise ValueError('Invalid label')
    torch.set_num_threads(4);torch.set_num_interop_threads(1)
    m=Model(Config());m.load_state_dict(load_file(str(args.weights)),strict=True);m.eval().requires_grad_(False)
    tok=Tokenizer.load(ROOT/'data/tokenizer.json');t0=time.monotonic();summary={};preds=[]
    for split in ['iid','surface','extrapolation','counterfactual']:
        rows=[json.loads(s) for s in (ROOT/f'data/{split}.jsonl').read_text().splitlines()]
        results=[]
        for row in rows:
            response=generate(m,tok,row['prompt'],96);ok,reason=score(row,response['completion'])
            item={'id':row['id'],'group':row['group'],'pair_id':row['pair_id'],'family':row['family'],'lang':row['lang'],'split':split,'prompt':row['prompt'],**response,'correct':ok,'score_reason':reason}
            results.append(item);preds.append(item)
        families={f:{'correct':sum(z['correct'] for z in results if z['family']==f),'n':sum(z['family']==f for z in results)} for f in sorted({z['family'] for z in results})}
        summary[split]={'correct':sum(z['correct'] for z in results),'n':len(results),'eos':sum(z['eos'] for z in results),'families':families,'mean_generated_tokens':sum(z['generated_tokens'] for z in results)/len(results)}
        if split=='counterfactual':
            pairs=collections.defaultdict(list)
            for z in results:pairs[z['pair_id']].append(z)
            if not all(len(v)==2 for v in pairs.values()):raise ValueError('Incomplete evaluation pairs')
            summary[split]['both_correct']=sum(all(z['correct'] for z in pair) for pair in pairs.values());summary[split]['pairs']=len(pairs)
        print(json.dumps({'label':args.label,'split':split,**summary[split]}),flush=True)
        (ROOT/f'metrics/{args.label}_predictions.jsonl').write_text(''.join(json.dumps(z,ensure_ascii=False)+'\n' for z in preds))
    atomic_json(ROOT/f'metrics/{args.label}_SUMMARY.json',{'label':args.label,'weights_sha256':digest(args.weights),'seconds':time.monotonic()-t0,'splits':summary,'status':'all_fixed_224_prompts_completed','broad_benchmark':False,'qwen_new_inference':False})
if __name__=='__main__':main()
