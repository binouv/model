"""Strictly verify exact native checkpoint, BF16 rounding and fixed inference."""
import argparse,gc,json
from pathlib import Path
import torch
from safetensors.torch import load_file
from engine import ROOT,load_checkpoint,Tokenizer,generate,digest
p=argparse.ArgumentParser();p.add_argument('--native',type=Path,required=True);p.add_argument('--bf16',type=Path,required=True);a=p.parse_args()
torch.set_num_threads(4);torch.set_num_interop_threads(1)
m,opt,rng,state=load_checkpoint(a.native)
if state['step']!=256:raise ValueError('Wrong final step')
expected=json.loads((ROOT/'reports/LOCAL_EXPORT_VERIFICATION.json').read_text())
if digest(a.bf16)!=expected['bf16_sha256']:raise ValueError('Wrong BF16 bytes')
b=load_file(str(a.bf16));native=m.state_dict()
if set(b)!=set(native) or not all(torch.equal(b[k],v.to(torch.bfloat16)) for k,v in native.items()):raise ValueError('BF16 export differs from exact rounding')
if not all(bool(torch.isfinite(v).all()) for vv in opt.state_dict()['state'].values() for v in vv.values() if isinstance(v,torch.Tensor)):raise ValueError('Nonfinite optimizer tensor')
native_hash=digest(a.native/'model.safetensors');optimizer_hash=digest(a.native/'training_state.pt')
del b,native,opt;gc.collect();m.eval().requires_grad_(False);tok=Tokenizer.load(ROOT/'data/tokenizer.json')
outputs=[]
for probe in expected['probes']:
    actual=generate(m,tok,probe['prompt'],96)
    if actual['generated_ids']!=probe['generated_ids']:raise ValueError('Fresh native inference did not reproduce')
    outputs.append({'prompt':probe['prompt'],'generated_ids':actual['generated_ids'],'completion':actual['completion']})
print(json.dumps({'native_step':state['step'],'native_model_sha256':native_hash,'training_state_sha256':optimizer_hash,'bf16_sha256':digest(a.bf16),'all_bf16_values_equal_native_rounding':True,'native_optimizer_loaded':True,'parameters':sum(v.numel() for v in m.parameters()),'matched_inference_probes':outputs,'remote_candidate_training_steps':0},ensure_ascii=False))
