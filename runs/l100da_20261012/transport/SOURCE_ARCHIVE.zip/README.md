# L100DA — completed full-100M continuation pilot

256 real local CPU updates, primary gate failed; **not a Qwen competitor yet**. See `reports/REPORT_RU.md`, `metrics/COMPLETED_SUMMARY.json` and the complete raw predictions. Source/data bundle is independent of large model bytes. Final Git publication is confirmed only by `transport/PUBLISHED_VERIFIED.json`.

## Restore binary parts

From repository root (Python3.11+):

```sh
python runs/artifact_recovery_20261012/checkpoint_parts.py restore models/l100da_20261012_step0256/bf16 /tmp/l100da.bf16.safetensors
python runs/artifact_recovery_20261012/checkpoint_parts.py restore models/l100da_20261012_step0256/native /tmp/l100da-native.zip
python -m zipfile -e /tmp/l100da-native.zip /tmp/l100da-native
cd runs/l100da_20261012
python -m pip install -r requirements.txt
pytest -q tests
python src/verify_export.py --native /tmp/l100da-native --bf16 /tmp/l100da.bf16.safetensors
python src/infer.py --weights /tmp/l100da.bf16.safetensors --sha256 1c8b86de8cb6513f841d77b675245216f17b340da790d3c8f053770cd09b7379 --prompt 'Calculate: 5 + 8. Answer:' --max-new-tokens 96
```

For separately downloaded parts use `src/checkpoint_parts.py` with the directory containing all parts and its `MANIFEST.json`. Restore refuses to overwrite existing output. Do not call byte-parts independent model shards.

## Do not restart completed training

`src/resume_checked.py` refuses to replay this completed256-step experiment. Its native checkpoint preserves model, AdamW, Python/Torch RNG, data sampler, config and immutable source/data identities. Only incomplete segments should use its guarded resume. A new continuation beyond256 requires a separately registered run/schedule; preserve inherited optimizer and all identities rather than silently changing this experiment's endpoint.

The included `train.py` and data can reproduce the finite historical experiment in an isolated fresh directory; never re-execute it over an existing completed run. Parent EC checksum and all hyperparameters are fixed in `configs/preregistered.json`. The available EC parent has no original optimizer: the start of L100DA was a weight-only warm start, not exact recovery of EC.

Environment used: PyTorch2.10.0+cpu, four CPU threads, FP32 model/AdamW with BF16 compute. No remote candidate training, no paid API and no user GPU. Exact cross-hardware float replay is not guaranteed. Qwen baseline, broad language evaluation and multi-seed confirmation remain absent.
