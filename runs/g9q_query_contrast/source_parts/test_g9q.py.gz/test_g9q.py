import json,sys,torch
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'base')]
import g9q
from model import Model,Config

def test_param_count():assert sum(p.numel() for p in Model(Config()).parameters())==469648
def test_data_fresh_and_pairs():
 g9q.build_data();m=json.loads((ROOT/'data/manifest.json').read_text());assert m['canonical_overlap']==0 and m['g9_value_min']>m['known_parent_value_max']
 for s in ['train','validation',*g9q.SPLITS]:
  z=g9q.read_pairs(s);assert len({p['canonical'] for p in z})==len(z)
  for p in z[:20]:assert p['rows'][0]['writes']==p['rows'][1]['writes'] and p['rows'][0]['query']!=p['rows'][1]['query'] and p['rows'][0]['answer']!=p['rows'][1]['answer']
def test_objective_equal_sequence_count_and_gradients():
 g9q.build_data();pairs=g9q.read_pairs('train')[:8]
 for arm in g9q.ARMS:
  torch.manual_seed(1);m=Model(Config());loss,parts=g9q.objective(m,pairs,arm);loss.backward();assert torch.isfinite(loss) and parts['positive_nll']>0 and all(p.grad is not None for p in m.parameters())
def test_parser_strict():
 assert g9q.parse('F=123')==123 and g9q.parse('F=-3')==-3
 for x in ['123','F=123 extra','F=1;F=2','T=x;F=3']:assert g9q.parse(x) is None
def test_model_causal():
 torch.manual_seed(4);m=Model(Config(dim=32,heads=4,hidden=64,key_dim=4)).eval();x=torch.randint(3,259,(1,20));y=x.clone();y[:,10:]=torch.randint(3,259,(1,10))
 with torch.no_grad():a,_=m(x);b,_=m(y)
 assert torch.allclose(a[:,:10],b[:,:10],atol=2e-6)
