from __future__ import annotations
import argparse,collections,copy,csv,hashlib,json,math,os,random,re,sys,time
from pathlib import Path
import torch
from torch.nn import functional as F
from safetensors.torch import save_file,load_file
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'base'))
from model import Model,Config,ByteTokenizer,EOS
ARMS=('hard_query_negative','random_negative_control')
SEEDS=(7601,7602,7603)
SPLITS=('iid','surface','extrapolation','counterfactual')

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.tmp');tmp.write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False));os.replace(tmp,p)
def h(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def canonical(writes):
 hist={k:[] for k in 'abcd'}
 for k,v in writes:hist[k].append(v)
 return h(hist)
def current(writes):
 m={}
 for k,v in writes:m[k]=v
 return m
def make_pair(r,updates=12,lo=300,hi=899,variant=0,pid=''):
 while True:
  vals=r.sample(range(lo,hi+1),4);w=[[k,v] for k,v in zip('abcd',vals)]
  for _ in range(updates-4):w.append([r.choice('abcd'),r.randint(lo,hi)])
  # Global interleaving is part of chronology; pair uses exactly the same writes.
  m=current(w)
  if len(set(m.values()))<4:continue
  q1,q2=r.sample(list('abcd'),2)
  if m[q1]==m[q2]:continue
  break
 def prompt(q):
  body='; '.join(f'{k}={v}' for k,v in w)
  if variant==0:return f'Writes in time order: {body}. Read the latest value of key {q}.\nAnswer:\nFinish with F=<integer>.\n'
  return f'Apply updates chronologically: {body}. Which current integer is stored at {q}?\nAnswer:\nFinish with F=<integer>.\n'
 rows=[]
 for q in [q1,q2]:
  ans=str(m[q]);p=prompt(q);rows.append({'id':h({'w':w,'q':q,'v':variant,'pid':pid}),'pair_id':pid,'canonical':canonical(w),'writes':w,'query':q,'answer':ans,'prompt':p,'family':'memory_update'})
 assert rows[0]['answer']!=rows[1]['answer'] and len(rows[0]['answer'])==len(rows[1]['answer'])==3
 return {'pair_id':pid,'canonical':canonical(w),'rows':rows}

def build_data():
 out=ROOT/'data';out.mkdir(exist_ok=True)
 specs=[('train',4096,91001,12,300,899,0),('validation',256,91002,12,300,899,0),('iid',200,91003,12,300,899,0),('surface',200,91004,12,300,899,1),('extrapolation',200,91005,20,900,999,1),('counterfactual',200,91006,12,300,899,0)]
 occupied=set();manifest={}
 for split,n,seed,updates,lo,hi,var in specs:
  r=random.Random(seed);pairs=[];attempt=0
  while len(pairs)<n:
   attempt+=1
   z=make_pair(r,updates,lo,hi,var,f'{split}_{len(pairs):05d}')
   if z['canonical'] in occupied:continue
   # protect model max-context including target and EOS
   tok=ByteTokenizer()
   if max(len(tok.encode(x['prompt'],bos=True))+len(tok.encode('F='+x['answer'],eos=True)) for x in z['rows'])>256:continue
   pairs.append(z);occupied.add(z['canonical'])
  p=out/f'{split}.jsonl';p.write_text(''.join(json.dumps(z,separators=(',',':'))+'\n' for z in pairs))
  manifest[split]={'pairs':n,'questions':2*n,'seed':seed,'updates':updates,'range':[lo,hi],'variant':var,'sha256':sha(p),'attempts':attempt}
 put(out/'manifest.json',{'status':'completed','canonical_overlap':0,'known_parent_value_max':255,'g9_value_min':300,'split_groups':sum(x['pairs'] for x in manifest.values()),'splits':manifest})
 return manifest

def read_pairs(split):return [json.loads(x) for x in (ROOT/'data'/f'{split}.jsonl').read_text().splitlines()]
def target_tokens(answer):return ByteTokenizer().encode('F='+answer,eos=True)
def seq_record(prompt,answer):
 tok=ByteTokenizer();pt=tok.encode(prompt,bos=True);ct=target_tokens(answer);return {'tokens':pt+ct,'prompt_tokens':len(pt),'target_len':len(ct)}
def score_sequences(m,seqs):
 # All prompts/answers in a training batch are same byte length by construction.
 lens=[len(z['tokens']) for z in seqs];starts=[z['prompt_tokens']-1 for z in seqs]
 if len(set(starts))!=1 or len(set(lens))!=1:raise ValueError('training score batch must be compute-matched')
 x=torch.tensor([z['tokens'][:-1] for z in seqs],dtype=torch.long);target=torch.tensor([z['tokens'][1:] for z in seqs],dtype=torch.long)
 logits,_=m(x);lp=F.log_softmax(logits.float(),-1);g=lp.gather(-1,target[...,None]).squeeze(-1)
 vals=[]
 for i,z in enumerate(seqs):vals.append(g[i,starts[i]:].mean())
 return torch.stack(vals)
def choose_random_negative(pairs,i,side):
 pos=pairs[i]['rows'][side]['answer'];need=len(pairs[i]['rows'][1-side]['answer'])
 for off in range(1,len(pairs)):
  cand=pairs[(i+off)%len(pairs)]['rows'][side]['answer']
  if cand!=pos and len(cand)==need:return cand
 raise RuntimeError('no random negative')
def objective(m,pairs,arm):
 seqs=[]
 for i,p in enumerate(pairs):
  a,b=p['rows'];
  if arm=='hard_query_negative':na,nb=b['answer'],a['answer']
  else:na,nb=choose_random_negative(pairs,i,0),choose_random_negative(pairs,i,1)
  seqs += [seq_record(a['prompt'],a['answer']),seq_record(a['prompt'],na),seq_record(b['prompt'],b['answer']),seq_record(b['prompt'],nb)]
 s=score_sequences(m,seqs).view(len(pairs),4)
 pos=-0.5*(s[:,0]+s[:,2]).mean();margin=0.5
 contrast=0.5*(F.softplus(margin-(s[:,0]-s[:,1]))+F.softplus(margin-(s[:,2]-s[:,3]))).mean()
 return pos+0.5*contrast,{'positive_nll':float(pos.detach()),'contrastive':float(contrast.detach()),'pair_margin':float((0.5*((s[:,0]-s[:,1])+(s[:,2]-s[:,3]))).mean().detach())}
def parse(text):
 m=re.fullmatch(r'F=(-?\d+)',text.strip());return int(m.group(1)) if m else None
@torch.inference_mode()
def generate(m,prompts):
 tok=ByteTokenizer();groups=collections.defaultdict(list);out=[None]*len(prompts)
 for i,p in enumerate(prompts):groups[len(tok.encode(p,bos=True))].append((i,p))
 seconds=0
 for _,g in sorted(groups.items()):
  for j in range(0,len(g),32):
   bb=g[j:j+32];ids=torch.tensor([tok.encode(p,bos=True) for _,p in bb]);t=time.perf_counter();z=m.generate(ids,torch.full((len(bb),),ids.shape[1]),max_new=32);seconds+=time.perf_counter()-t
   for (idx,_),seq in zip(bb,z.tolist()):
    eos=EOS in seq;seq=seq[:seq.index(EOS)] if eos else seq;out[idx]={'text':tok.decode(seq),'ids':seq,'eos':eos}
 return out,seconds
@torch.inference_mode()
def evaluate(m,pairs):
 rows=[];prompts=[r['prompt'] for p in pairs for r in p['rows']];pred,sec=generate(m,prompts);k=0;sens=0;both=0
 for p in pairs:
  pr=[]
  for r in p['rows']:
   z=pred[k];k+=1;v=parse(z['text']);ok=z['eos'] and v is not None and v==int(r['answer']);q={**z,'id':r['id'],'pair_id':p['pair_id'],'query':r['query'],'gold':r['answer'],'parsed':v,'exact':ok};rows.append(q);pr.append(q)
  both+=int(all(x['exact'] for x in pr));sens+=int(pr[0]['parsed']!=pr[1]['parsed'])
 return {'status':'completed','pairs':len(pairs),'questions':2*len(pairs),'correct':sum(x['exact'] for x in rows),'accuracy':sum(x['exact'] for x in rows)/(2*len(pairs)),'both_correct_pairs':both,'pair_accuracy':both/len(pairs),'query_sensitivity':sens/len(pairs),'truncated':sum(not x['eos'] for x in rows),'generation_seconds':sec,'rows':rows}
def load_parent(seed):
 p=Path(os.environ.get('G9_PARENT_DIR','/mnt/data/g9q_work/g8/flygraph_g8c/checkpoints'))/f'verified_trace_s{seed}'/'step2000'/'resume.pt';st=torch.load(p,weights_only=False,map_location='cpu')
 assert st['schema']=='G8C_v1' and st['step']==2000 and st['seed']==seed and st['arm']=='verified_trace';return p,st
def restore_parent(st):
 m=Model(Config(**st['config']));m.load_state_dict(st['model']);opt=torch.optim.AdamW(m.parameters(),lr=.001,betas=(.9,.95),weight_decay=.01);opt.load_state_dict(copy.deepcopy(st['optimizer']));return m,opt
def state_hash(m):
 hsh=hashlib.sha256()
 for k,v in sorted(m.state_dict().items()):hsh.update(k.encode());hsh.update(v.detach().cpu().contiguous().numpy().tobytes())
 return hsh.hexdigest()
def save(m,opt,rng,arm,seed,step,logs,parent_sha):
 cp=ROOT/'checkpoints'/f'{arm}_s{seed}'/f'step{step:04d}';cp.mkdir(parents=True,exist_ok=False)
 state={'schema':'G9Q_v1','config':m.config.__dict__,'arm':arm,'seed':seed,'step':step,'parent_global_step':2000,'parent_checkpoint_sha256':parent_sha,'model':m.state_dict(),'optimizer':opt.state_dict(),'sampler_rng':rng.getstate(),'python_rng':random.getstate(),'torch_rng':torch.get_rng_state(),'logs':logs,'preregistered_sha256':sha(ROOT/'configs/preregistered.json')}
 torch.save(state,cp/'resume.pt');save_file({k:v.detach().contiguous() for k,v in m.state_dict().items()},str(cp/'model.safetensors'));put(cp/'config.json',m.config.__dict__);put(cp/'MANIFEST.json',{'step':step,'parameters':sum(p.numel() for p in m.parameters()),'files':{n:{'bytes':(cp/n).stat().st_size,'sha256':sha(cp/n)} for n in ['resume.pt','model.safetensors','config.json']},'optimizer_rng':True});(cp/'COMPLETE').write_text('complete\n');return cp
def train(arm,seed):
 out=ROOT/'metrics'/f'{arm}_s{seed}.json'
 if out.exists():raise FileExistsError('refuse duplicate completed run')
 parent_path,st=load_parent(seed);m,opt=restore_parent(st);torch.manual_seed(seed+90000);random.seed(seed+90000);rng=random.Random(91911)
 train_pairs=read_pairs('train');val_pairs=read_pairs('validation');logs=[];bh=hashlib.sha256();t0=time.perf_counter();initial=state_hash(m)
 for step in range(1,1001):
  idx=[rng.randrange(len(train_pairs)) for _ in range(8)];bb=[train_pairs[i] for i in idx];opt.zero_grad(set_to_none=True);start=time.perf_counter();loss,parts=objective(m,bb,arm);loss.backward();gn=float(torch.nn.utils.clip_grad_norm_(m.parameters(),1.));lr=.0002*(.2+.8*.5*(1+math.cos(math.pi*step/1000)))
  for g in opt.param_groups:g['lr']=lr
  opt.step();row={'step':step,'loss':float(loss.detach()),**parts,'grad_norm':gn,'lr':lr,'seconds':time.perf_counter()-start,'pair_ids':[p['pair_id'] for p in bb],'scored_sequences':32};logs.append(row)
  for x in row['pair_ids']:bh.update((x+'\n').encode())
  with (ROOT/'metrics'/f'{arm}_s{seed}.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
  if step%100==0:print('TRAIN',arm,seed,step,round(row['loss'],4),round(row['pair_margin'],3),flush=True)
  if step%250==0:
   cp=save(m,opt,rng,arm,seed,2000+step,logs,sha(parent_path));put(ROOT/'reports/NEXT_STATE.json',{'status':'running_local','run':'G9Q','arm':arm,'seed':seed,'stage3_step':step,'checkpoint':str(cp),'do_not_duplicate':True})
 val=evaluate(m,val_pairs);tests={s:evaluate(m,read_pairs(s)) for s in SPLITS}
 # reload safetensors
 n=Model(Config(**m.config.__dict__));n.load_state_dict(load_file(str(cp/'model.safetensors')));a=evaluate(m,read_pairs('iid')[:8])['rows'];b=evaluate(n,read_pairs('iid')[:8])['rows'];assert a==b
 # native resume deterministic next update replay
 native=torch.load(cp/'resume.pt',weights_only=False,map_location='cpu');hashes=[]
 for _ in range(2):
  nn=Model(Config(**native['config']));nn.load_state_dict(native['model']);oo=torch.optim.AdamW(nn.parameters(),lr=.001,betas=(.9,.95),weight_decay=.01);oo.load_state_dict(copy.deepcopy(native['optimizer']));rr=random.Random();rr.setstate(native['sampler_rng']);idx=[rr.randrange(len(train_pairs)) for _ in range(8)];bb=[train_pairs[i] for i in idx];oo.zero_grad(set_to_none=True);ll,_=objective(nn,bb,arm);ll.backward();torch.nn.utils.clip_grad_norm_(nn.parameters(),1.);oo.step();hashes.append(state_hash(nn))
 assert hashes[0]==hashes[1] and all(torch.isfinite(p).all() for p in m.parameters())
 res={'status':'completed','arm':arm,'seed':seed,'parameters':sum(p.numel() for p in m.parameters()),'parent_checkpoint':str(parent_path),'parent_sha256':sha(parent_path),'parent_state_sha256':initial,'final_state_sha256':state_hash(m),'additional_steps':1000,'scored_sequences_per_step':32,'batch_sequence_sha256':bh.hexdigest(),'train_seconds':sum(z['seconds'] for z in logs),'validation':val,'tests':tests,'checkpoint':str(cp),'checkpoint_manifest':json.loads((cp/'MANIFEST.json').read_text()),'reload_cases':16,'reload_mismatches':0,'next_update_replay_verified':True,'all_weights_finite':True}
 put(out,res);print('DONE',arm,seed,{s:(tests[s]['correct'],tests[s]['both_correct_pairs'],round(tests[s]['query_sensitivity'],3)) for s in SPLITS},flush=True);return res

def paired_rows(a,b):
 aa={z['id']:z['exact'] for z in a};bb={z['id']:z['exact'] for z in b};assert set(aa)==set(bb);w=sum(aa[k] and not bb[k] for k in aa);l=sum(bb[k] and not aa[k] for k in aa);n=w+l;p=1.0 if n==0 else min(1.0,2*sum(math.comb(n,i) for i in range(min(w,l)+1))/2**n);return {'wins':w,'losses':l,'delta_pp':100*(w-l)/len(aa),'exact_two_sided_p':p}
def aggregate():
 rows=[json.loads((ROOT/'metrics'/f'{a}_s{s}.json').read_text()) for s in SEEDS for a in ARMS];assert len(rows)==6 and all(z['status']=='completed' for z in rows)
 assert all(next(z for z in rows if z['seed']==s and z['arm']==ARMS[0])['batch_sequence_sha256']==next(z for z in rows if z['seed']==s and z['arm']==ARMS[1])['batch_sequence_sha256'] for s in SEEDS)
 metrics={};paired={}
 for arm in ARMS:
  rr=[z for z in rows if z['arm']==arm];metrics[arm]={sp:{'question_accuracy_mean':sum(z['tests'][sp]['accuracy'] for z in rr)/3,'pair_accuracy_mean':sum(z['tests'][sp]['pair_accuracy'] for z in rr)/3,'query_sensitivity_mean':sum(z['tests'][sp]['query_sensitivity'] for z in rr)/3,'correct_by_seed':[z['tests'][sp]['correct'] for z in rr],'both_correct_by_seed':[z['tests'][sp]['both_correct_pairs'] for z in rr]} for sp in SPLITS}
 for s in SEEDS:
  a=next(z for z in rows if z['seed']==s and z['arm']==ARMS[0]);b=next(z for z in rows if z['seed']==s and z['arm']==ARMS[1]);paired[str(s)]={sp:paired_rows(a['tests'][sp]['rows'],b['tests'][sp]['rows']) for sp in SPLITS}
 gains={sp:{k:100*(metrics[ARMS[0]][sp][k]-metrics[ARMS[1]][sp][k]) for k in ['question_accuracy_mean','pair_accuracy_mean','query_sensitivity_mean']} for sp in SPLITS}
 gates={'iid_question_gain_ge3pp':gains['iid']['question_accuracy_mean']>=3,'iid_pair_gain_ge2pp':gains['iid']['pair_accuracy_mean']>=2,'query_sensitivity_gain_ge10pp':gains['iid']['query_sensitivity_mean']>=10,'positive_iid_question_gain_seeds':sum(paired[str(s)]['iid']['delta_pp']>0 for s in SEEDS)>=2,'surface_extrap_pair_regression_ok':min(gains['surface']['pair_accuracy_mean'],gains['extrapolation']['pair_accuracy_mean'])>=-2}
 verdict='SUPPORTED_IN_REGISTERED_PROTOCOL' if all(gates.values()) else 'NOT_CONFIRMED_IN_REGISTERED_PROTOCOL'
 out={'run':'G9Q','status':'completed','hypothesis':'hard same-state query negatives improve query grounding over random negatives at matched scoring compute','parameters_each':469648,'new_random_initializations':0,'ancestral_seeds':list(SEEDS),'completed_continuations':6,'steps_each':1000,'metrics':metrics,'gains_pp':gains,'paired':paired,'gates':gates,'verdict':verdict,'training_compute_match':{'scored_sequences_per_step':32,'updates':1000,'batch_pairs':8,'target_bytes_equal':True},'scope':'small synthetic memory-grounding probe; not300-800M, not Qwen parity'}
 put(ROOT/'metrics/FINAL.json',out)
 with (ROOT/'metrics/FINAL.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['arm','seed','split','questions','correct','pairs','both_correct','query_sensitivity','truncated'])
  for z in rows:
   for sp,t in z['tests'].items():w.writerow([z['arm'],z['seed'],sp,t['questions'],t['correct'],t['pairs'],t['both_correct_pairs'],t['query_sensitivity'],t['truncated']])
 put(ROOT/'reports/NEXT_STATE.json',{'status':'completed','run':'G9Q','verdict':verdict,'goal_300_800m_qwen_thinking_not_achieved':True,'do_not_repeat':['G8C','G9Q'],'next':'If hard negatives fail to improve both-correct pairs, stop optimizing scalar answer discrimination and move to explicit discrete key selection / pointer supervision as a separate registered mechanism. If supported, transfer query-contrastive objective into a larger RU/EN/code hybrid backbone.'})
 (ROOT/'reports/RESEARCH_REPORT_RU.md').write_text('# FlyGraph G9Q\n\n'+json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--build-data',action='store_true');ap.add_argument('--arm',choices=ARMS);ap.add_argument('--seed',type=int,choices=SEEDS);ap.add_argument('--aggregate',action='store_true');a=ap.parse_args();torch.set_num_threads(4);torch.set_num_interop_threads(1)
 if a.build_data:print(json.dumps(build_data(),indent=2));return
 if a.aggregate:print(json.dumps(aggregate(),indent=2));return
 if a.arm is None or a.seed is None:raise SystemExit('need --arm and --seed')
 train(a.arm,a.seed)
if __name__=='__main__':main()
