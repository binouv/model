from __future__ import annotations
import gzip,hashlib,json,os,shutil,subprocess,tarfile,tempfile
from pathlib import Path
import g9q
ROOT=g9q.ROOT;REPO='binouv/model';BRANCH='flygraph/g9q-query-contrast-20260929';PARENT_TAG='flygraph-g8c-consolidation-36238890991'
PARENTS={
7601:{'bytes':6261190,'sha256':'8dc94305108b1dd97f68f4d4b3d54c95e34e380847a2b04752b90eb8bcd1164e'},
7602:{'bytes':6261190,'sha256':'f4d5239f1e59c94f64666d7528f655efa1a1fdf7829b0826604297fb481fe69a'},
7603:{'bytes':6261126,'sha256':'195ec50d85347cd124d09bfb65ef4f848075da7755d069c4d177f3057c4daa4c'}}
def sh(*args):subprocess.check_call(args)
def out(*args):return subprocess.check_output(args,text=True).strip()
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(4<<20),b''):h.update(b)
 return h.hexdigest()
def commit(paths,msg):
 for p in paths:sh('git','add',str(p.relative_to(ROOT.parents[1])))
 if subprocess.call(['git','diff','--cached','--quiet'])==0:return
 sh('git','commit','-m',msg);sh('git','push','origin','HEAD:'+BRANCH)
def upload(tag,paths):
 sh('gh','release','upload',tag,'--repo',REPO,*map(str,paths));receipt=[]
 with tempfile.TemporaryDirectory() as td:
  for p in paths:
   sh('gh','release','download',tag,'--repo',REPO,'--pattern',p.name,'--dir',td);q=Path(td)/p.name
   assert q.stat().st_size==p.stat().st_size and sha(q)==sha(p)
   receipt.append({'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p),'remote_redownload_sha256_verified':True})
 return receipt
def main():
 assert os.environ['GITHUB_REPOSITORY']==REPO
 # authenticated non-force branch updates; workflow trigger file is never modified here
 sh('git','config','user.name','github-actions[bot]');sh('git','config','user.email','41898282+github-actions[bot]@users.noreply.github.com')
 sh('git','remote','set-url','origin',f"https://x-access-token:{os.environ['GH_TOKEN']}@github.com/{REPO}.git")
 parents=ROOT/'parents';parents.mkdir(exist_ok=True)
 for seed,exp in PARENTS.items():
  d=parents/f'verified_trace_s{seed}'/'step2000';d.mkdir(parents=True,exist_ok=True);name=f'verified_trace_s{seed}_stage2_1000.resume.pt'
  sh('gh','release','download',PARENT_TAG,'--repo',REPO,'--pattern',name,'--dir',str(d));src=d/name;dst=d/'resume.pt';src.rename(dst)
  assert dst.stat().st_size==exp['bytes'] and sha(dst)==exp['sha256']
 os.environ['G9_PARENT_DIR']=str(parents)
 g9q.build_data();expected=json.loads((ROOT/'configs/data_expected.json').read_text())
 actual=json.loads((ROOT/'data/manifest.json').read_text())['splits'];assert {k:v['sha256'] for k,v in actual.items()}==expected
 tag='flygraph-g9q-query-contrast-'+os.environ['GITHUB_RUN_ID'];sh('gh','release','create',tag,'--repo',REPO,'--target',os.environ['GITHUB_SHA'],'--title','FlyGraph G9Q: query-grounding contrastive research checkpoints','--notes','DRAFT until six matched continuations finish. Small469648-param memory mechanism probe, not300-800M/Qwen parity.','--draft','--prerelease')
 receipts=[]
 for seed in g9q.SEEDS:
  for arm in g9q.ARMS:
   z=g9q.train(arm,seed);cp=Path(z['checkpoint']);stem=f'{arm}_s{seed}';assets=ROOT/'assets';assets.mkdir(exist_ok=True);paths=[]
   for old,new in [('resume.pt',stem+'.resume.pt'),('model.safetensors',stem+'.safetensors'),('config.json',stem+'.config.json')]:
    p=assets/new;shutil.copy2(cp/old,p);paths.append(p)
   raw=assets/(stem+'.RAW.json.gz');raw.write_bytes(gzip.compress((ROOT/'metrics'/f'{arm}_s{seed}.json').read_bytes(),mtime=0));paths.append(raw)
   steps=assets/(stem+'.STEPS.jsonl.gz');steps.write_bytes(gzip.compress((ROOT/'metrics'/f'{arm}_s{seed}.jsonl').read_bytes(),mtime=0));paths.append(steps)
   receipts += upload(tag,paths)
   summary=ROOT/'reports'/f'{stem}.COMPLETED.json';compact={k:v for k,v in z.items() if k not in ('validation','tests')};compact['validation']={k:v for k,v in z['validation'].items() if k!='rows'};compact['tests']={s:{k:v for k,v in t.items() if k!='rows'} for s,t in z['tests'].items()};compact['release_assets']=[r for r in receipts if r['name'].startswith(stem)];summary.write_text(json.dumps(compact,indent=2))
   commit([ROOT/'metrics'/f'{arm}_s{seed}.json',ROOT/'metrics'/f'{arm}_s{seed}.jsonl',summary,ROOT/'reports/NEXT_STATE.json'],f'FlyGraph G9Q: completed {arm} seed{seed} with native checkpoint')
 final=g9q.aggregate();commit([ROOT/'metrics/FINAL.json',ROOT/'metrics/FINAL.csv',ROOT/'reports/RESEARCH_REPORT_RU.md',ROOT/'reports/NEXT_STATE.json'],f"FlyGraph G9Q: finalize paired result {final['verdict']}")
 archive=ROOT/'assets'/'SOURCE_DATA_RESULTS.tar.gz'
 with tarfile.open(archive,'w:gz') as tf:
  for folder in ['src','tests','configs','base','data','metrics','reports']:
   for p in sorted((ROOT/folder).rglob('*')):
    if p.is_file() and 'parents' not in p.parts and 'checkpoints' not in p.parts:tf.add(p,arcname=str(p.relative_to(ROOT)))
 receipts += upload(tag,[archive])
 manifest=ROOT/'assets'/'MANIFEST.json';manifest.write_text(json.dumps({'status':'completed','tag':tag,'workflow_run':os.environ['GITHUB_RUN_ID'],'source_commit':os.environ['GITHUB_SHA'],'models':6,'ancestral_seeds':list(g9q.SEEDS),'new_independent_initializations':0,'native_optimizer_rng_present':True,'all_assets_redownload_verified':True,'assets':receipts},indent=2));upload(tag,[manifest])
 sh('gh','release','edit',tag,'--repo',REPO,'--draft=false','--prerelease','--notes',f"Six completed G9Q matched continuations from real G8C trace parents. Main hard same-state query negatives vs random-negative control,3 ancestral seeds,1000 updates each. Actual safetensors/native optimizer+RNG/raw metrics. Every payload redownloaded and SHA256 verified. Verdict: {final['verdict']}. Small English synthetic memory probe, not300-800M or Qwen parity.")
 receipt=ROOT/'reports/RELEASE_RECEIPT.json';receipt.write_text(json.dumps({'status':'six_continuations_completed','tag':tag,'workflow_run':os.environ['GITHUB_RUN_ID'],'assets':receipts,'native_optimizer_rng_present':True,'all_assets_redownload_verified':True},indent=2));commit([receipt], 'FlyGraph G9Q: publish actual checkpoint release receipt')
 print('FG_FINAL',json.dumps({'tag':tag,'verdict':final['verdict'],'gains_pp':final['gains_pp']}),flush=True)
if __name__=='__main__':main()
