"""Registered L100K paired experiment. Exact 1024 steps, full resumable native adapter states."""
from __future__ import annotations
import argparse,hashlib,json,os,random,sys,time,platform,shutil,statistics
from pathlib import Path
import torch
from torch.nn import functional as F
from safetensors.torch import save_file,load_file
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from data import pairs,batch_collate
from reader import NeuralBytePointer,predict_value

def digest(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1<<20),b''):h.update(block)
    return h.hexdigest()

def text_hash(parts):
    h=hashlib.sha256()
    for x in parts:h.update(x.encode('ascii')+b'\x00')
    return h.hexdigest()

def fsynced_json(path:Path,data:dict):
    with path.open('x',encoding='utf-8') as out:
        json.dump(data,out,indent=2,ensure_ascii=False)
        out.write('\n');out.flush();os.fsync(out.fileno())

def save_checkpoint(model,opt,step,arm,config,data_hash,sampler_state,loss_history):
    folder=ROOT/'checkpoints'/arm/f'step_{step:04d}'
    if folder.exists():raise FileExistsError(folder)
    folder.parent.mkdir(parents=True,exist_ok=True)
    stage=folder.parent/f'.step_{step:04d}_tmp'
    if stage.exists():raise FileExistsError(stage)
    stage.mkdir()
    try:
        weights=stage/'model.safetensors'
        save_file({n:p.detach().contiguous().cpu() for n,p in model.state_dict().items()},str(weights))
        with weights.open('rb') as f:os.fsync(f.fileno())
        state={
            'step':step,'arm':arm,
            'optimizer':opt.state_dict(),
            'torch_rng':torch.get_rng_state(),
            'sampler_state':sampler_state,
            'loss_history':loss_history,
            'config_sha256':digest(ROOT/'configs'/'registered.json'),
            'data_sha256':data_hash,
            'python_random':random.getstate(),
            'parent_model_sha256':config['parent_checkpoint_sha256']
        }
        torch.save(state,stage/'training_state.pt')
        with (stage/'training_state.pt').open('rb') as f:os.fsync(f.fileno())
        meta={'format':'FlyGraph.L100K.checkpoint.v1', 'status':'completed_endpoint' if step==config['steps_each_arm'] else 'in_progress',
              'model':'NeuralBytePointer', 'arm':arm, 'step':step,
              'weights_size':weights.stat().st_size,'weights_sha256':digest(weights),
              'train_state_size':(stage/'training_state.pt').stat().st_size,
              'train_state_sha256':digest(stage/'training_state.pt'),
              'config_sha256':state['config_sha256'],'data_sha256':data_hash,
              'parent_model_sha256':config['parent_checkpoint_sha256'],
              'trainable_parameters':sum(x.numel() for x in model.parameters())}
        fsynced_json(stage/'MANIFEST.json',meta)
        # Strict readback before promoting to a durable local checkpoint.
        m2=NeuralBytePointer(query_aware=arm=='query_aware')
        m2.load_state_dict(load_file(str(weights)),strict=True)
        assert all(torch.equal(p,q) for p,q in zip(model.parameters(),m2.parameters()))
        assert digest(stage/'training_state.pt')==meta['train_state_sha256']
        stage.rename(folder)
    finally:
        if stage.exists():shutil.rmtree(stage)
    return meta

def training(config:dict):
    torch.set_num_threads(2)
    initial=121203
    train_pairs=pairs(config['train_seed'],config['training_banks'])
    flat=[x for pair in train_pairs for x in pair]
    bank_strings=[pair[0].prompt[:-1] for pair in train_pairs]
    assert len(set(bank_strings))==len(bank_strings),'duplicate banks'
    data_hash=text_hash([x.prompt+'\t'+str(x.source_start) for x in flat])
    logs={}
    for arm in ['query_aware','query_blind_control']:
        seed=121211
        torch.manual_seed(seed);random.seed(seed)
        model=NeuralBytePointer(query_aware=(arm=='query_aware'))
        opt=torch.optim.AdamW(model.parameters(),lr=config['lr'],weight_decay=config['weight_decay'],foreach=False)
        indices=random.Random(121212)
        losses=[]
        start=time.monotonic()
        for step in range(1,config['steps_each_arm']+1):
            sampled=indices.sample(range(len(train_pairs)),config['batch']//2)
            batch=[ex for idx in sampled for ex in train_pairs[idx]]
            ids,lengths,labels=batch_collate(batch)
            opt.zero_grad(set_to_none=True)
            out=model(ids,lengths)
            loss=F.cross_entropy(out,labels)
            if not torch.isfinite(loss):raise RuntimeError(f'nonfinite loss at {arm} step {step}')
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(),config['grad_clip'])
            opt.step()
            losses.append(float(loss.detach().item()))
            if step%config['checkpoint_steps']==0 or step==config['steps_each_arm']:
                meta=save_checkpoint(model,opt,step,arm,config,data_hash,indices.getstate(),losses)
                print(json.dumps({'arm':arm,'step':step,'loss_tail':round(statistics.mean(losses[-64:]),4),
                                  'elapsed_sec':round(time.monotonic()-start,2),
                                  'weights_sha256':meta['weights_sha256']}),flush=True)
        logs[arm]={'step':step,'elapsed_seconds':round(time.monotonic()-start,2),'last64_mean_loss':statistics.mean(losses[-64:]),
                   'data_sha256':data_hash,'trainable_parameters':sum(p.numel() for p in model.parameters())}
        del model,opt
    fsynced_json(ROOT/'metrics'/'TRAINING.json',logs)
    return logs

def evaluate(config:dict):
    from statistics import mean
    arms=['query_aware','query_blind_control']
    models={}
    for arm in arms:
        folder=ROOT/'checkpoints'/arm/f'step_{config["steps_each_arm"]:04d}'
        meta=json.loads((folder/'MANIFEST.json').read_text())
        assert meta['status']=='completed_endpoint' and meta['step']==config['steps_each_arm']
        weight=folder/'model.safetensors'
        assert digest(weight)==meta['weights_sha256']
        model=NeuralBytePointer(query_aware=arm=='query_aware')
        model.load_state_dict(load_file(str(weight)),strict=True)
        model.eval();models[arm]=model
    train_banks=set(x.prompt[:-1] for y in pairs(config['train_seed'],config['training_banks']) for x in y[:1])
    report={'protocol':config,'results':{},'held_train_overlap':{}}
    all_predictions=[]
    for split,setting in config['held'].items():
        family={'iid':'iid','paraphrase_larger_bank':'long','unseen_letters_wxyz':'unseen','new_5_to_6_digit_values':'wide'}[split]
        held=pairs(setting['seed'],setting['banks'],family)
        banks=set(p[0].prompt[:-1] for p in held)
        overlap=len(banks&train_banks)
        assert overlap==0, f'held train overlap {split}: {overlap}'
        report['held_train_overlap'][split]=overlap
        info={}
        for arm,model in models.items():
            both=0; correct=0; invalid=0; selected_positions_correct=0
            for first,second in held:
                row=[]
                for ex in (first,second):
                    prediction=predict_value(model,ex.prompt)
                    valid=prediction['value'] is not None
                    ok=prediction['value']==ex.value
                    source_ok=prediction['source_start']==ex.source_start
                    row.append(ok)
                    correct+=int(ok);invalid+=int(not valid);selected_positions_correct+=int(source_ok)
                    all_predictions.append({'arm':arm,'split':split,'bank_id':ex.bank_id,'prompt':ex.prompt,
                                            'gold':ex.value,'source_gold':ex.source_start,
                                            'predicted':prediction['value'],'source_pred':prediction['source_start'],
                                            'correct':ok,'source_correct':source_ok})
                both+=int(all(row))
            info[arm]={'banks':len(held),'questions':len(held)*2,'exact_answers':correct,
                       'both_correct_pairs':both,'invalid':invalid,'source_positions_correct':selected_positions_correct,
                       'question_accuracy':correct/(len(held)*2), 'pair_accuracy':both/len(held)}
        report['results'][split]=info
    # Paired bootstrap for the preregistered iid BOTH-CORRECT metric, using *per-bank* outputs.
    paired={arm:{} for arm in arms}
    for row in all_predictions:
        if row['split']=='iid':paired[row['arm']].setdefault(row['bank_id'],[]).append(row['correct'])
    differences=[int(all(paired['query_aware'][i]))-int(all(paired['query_blind_control'][i])) for i in range(config['held']['iid']['banks'])]
    rng=random.Random(config['bootstrap_seed'])
    bootstrap=[mean(rng.choices(differences,k=len(differences))) for _ in range(config['bootstrap_samples'])]
    bootstrap.sort()
    gain=mean(differences)
    lower=bootstrap[int(.025*len(bootstrap))]
    upper=bootstrap[int(.975*len(bootstrap))]
    report['primary']={'iid_pairs':len(differences),'query_aware_gain_pp':100*gain,'bootstrap95_pp':[100*lower,100*upper],
                       'passes_preregistered_gate':gain>=.1 and lower>0,
                       'bootstrap_samples':config['bootstrap_samples']}
    report['goal_better_than_Qwen3.5_0.8B_achieved']=False
    report['scoring_scope']='strict byte serialized memory copying only; not any general Qwen reference'
    (ROOT/'metrics'/'PREDICTIONS.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in all_predictions))
    fsynced_json(ROOT/'metrics'/'SUMMARY.json',report)
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--train',action='store_true');p.add_argument('--evaluate',action='store_true');args=p.parse_args()
    cfg=json.loads((ROOT/'configs'/'registered.json').read_text())
    if args.train:training(cfg)
    if args.evaluate:
        result=evaluate(cfg)
        print(json.dumps({'primary':result['primary'],'other_splits':result['results'],'broad_goal_achieved':False},indent=2))
