"""Tiny learned query-conditioned byte pointer for a strictly specified record stream.

Input is a single raw ASCII byte sequence: `a=120;b=45;a=7?b`.
The candidate start position is predicted over *all* bytes with a learned
local structural scorer and learned query/key matching. No regex, dictionary
lookup, numeric calculation, target labels or answer candidates at inference.
The byte-copy operator emits digits starting at the predicted source position.
It is a narrow neural memory component, NOT a general LM replacement.
"""
from __future__ import annotations
import torch
from torch import nn
from torch.nn import functional as F

class NeuralBytePointer(nn.Module):
    def __init__(self, width:int=16, hidden:int=48, query_aware:bool=True):
        super().__init__()
        self.query_aware=query_aware
        self.embedding=nn.Embedding(128,width)
        self.structure=nn.Sequential(nn.Linear(4*width,hidden),nn.GELU(),nn.Linear(hidden,1))
        self.log_match_scale=nn.Parameter(torch.tensor(-0.1))
        self.recency=nn.Parameter(torch.tensor(3.0))
        nn.init.normal_(self.embedding.weight,std=0.4)
    def forward(self, ids:torch.Tensor, lengths:torch.Tensor)->torch.Tensor:
        if ids.ndim!=2 or lengths.shape!=(ids.shape[0],):raise ValueError('invalid input shape')
        if ids.dtype!=torch.long or (ids<0).any() or (ids>127).any():raise ValueError('ASCII IDs expected')
        B,T=ids.shape
        e=self.embedding(ids)
        # Candidate at i sees bytes [i-2,i-1,i,i+1] through the same trainable filter.
        empty=torch.zeros(B,2,e.shape[-1],device=e.device,dtype=e.dtype)
        prev2=torch.cat((empty,e[:,:-2]),dim=1) if T>=2 else torch.zeros_like(e)
        prev1=torch.cat((empty[:,:1],e[:,:-1]),dim=1)
        nxt1=torch.cat((e[:,1:],empty[:,:1]),dim=1)
        features=torch.cat((prev2,prev1,e,nxt1),dim=-1)
        structural=self.structure(features).squeeze(-1)
        q=self.embedding(ids.gather(1,(lengths-1)[:,None]).squeeze(1))
        similarity=((prev2-q[:,None])**2).mean(dim=-1)
        rel=torch.arange(T,device=ids.device)[None].float() / (lengths.float()[:,None].clamp(min=1))
        logits=structural+self.recency*rel
        if self.query_aware:
            logits=logits-self.log_match_scale.exp()*similarity
        mask=torch.arange(T,device=ids.device)[None] >= (lengths[:,None]-2)
        return logits.masked_fill(mask,torch.finfo(logits.dtype).min)

def predict_value(model:NeuralBytePointer,prompt:str)->dict:
    raw=prompt.encode('ascii')
    if len(raw)<8 or any(c>=128 for c in raw) or raw[-2]!=ord('?'):
        raise ValueError('Strict byte-memory serialization expected: a=1;b=2?a')
    ids=torch.tensor([list(raw)],dtype=torch.long)
    lens=torch.tensor([len(raw)],dtype=torch.long)
    with torch.inference_mode():
        score=model(ids,lens)[0]
        source_pos=int(score.argmax().item())
    end=source_pos
    while end<len(raw) and 48<=raw[end]<=57:
        end+=1
    raw_value=raw[source_pos:end].decode('ascii')
    return {'value':raw_value if raw_value else None,'source_start':source_pos,
            'query_aware':model.query_aware,'tokens_seen':len(raw),
            'uses_symbolic_key_lookup':False,'value_copied_from_input':True}
