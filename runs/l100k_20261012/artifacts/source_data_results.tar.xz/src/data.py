"""Deterministic synthetic memory banks with disjoint groups."""
from __future__ import annotations
import random
from dataclasses import dataclass

@dataclass(frozen=True)
class Example:
    prompt:str
    value:str
    source_start:int
    family:str
    bank_id:int

# The two query variants share the same bank. Disjoint seeds ensure no repeated banks.
def pairs(seed:int, n:int, family:str='iid') -> list[tuple[Example,Example]]:
    rng=random.Random(seed)
    out=[]
    for i in range(n):
        if family=='long':
            letters='abcdefghijklmnopqrstuv'; count=rng.randint(20,32); min_d,max_d=2,3
        elif family=='unseen':
            letters='wxyz'; count=rng.randint(7,12); min_d,max_d=2,3
        elif family=='wide':
            letters='abcdefghijklmnopqrstuv';count=rng.randint(7,12);min_d,max_d=5,6
        else:
            letters='abcdefghijklmnopqrstuv';count=rng.randint(7,12);min_d,max_d=2,3
        keys=rng.sample(letters,k=min(len(letters),rng.randint(2,4)))
        writes=[]
        used_values=set()
        for position in range(count):
            k=keys[position] if position<2 else rng.choice(keys)
            digits=rng.randint(min_d,max_d)
            number=rng.randint(10**(digits-1),10**digits-1)
            while str(number) in used_values:
                number=rng.randint(10**(digits-1),10**digits-1)
            used_values.add(str(number))
            writes.append((k,str(number)))
        latest={}
        ser=''
        for k,v in writes:
            latest[k]=(len(ser)+len(k)+1,v)
            ser+=k+'='+v+';'
        # Select two *different* queried keys, so the model must switch on query.
        q1=rng.choice(list(latest.keys()))
        choices=[k for k in latest if k!=q1 and latest[k][1]!=latest[q1][1]]
        assert choices, 'last value uniqueness invariant' 
        q2=rng.choice(choices)
        one,two=[] ,[]
        for q in (q1,q2):
            pos,v=latest[q]
            p=ser+'?'+q
            ex=Example(prompt=p,value=v,source_start=pos,family=family,bank_id=i)
            if q==q1:one=ex
            else:two=ex
        out.append((one,two))
    return out

def batch_collate(examples):
    import torch
    raw=[list(x.prompt.encode('ascii')) for x in examples]
    lengths=torch.tensor([len(x) for x in raw],dtype=torch.long)
    ids=torch.zeros(len(raw),max(lengths.tolist()),dtype=torch.long)
    for j,x in enumerate(raw):ids[j,:len(x)]=torch.tensor(x,dtype=torch.long)
    labels=torch.tensor([x.source_start for x in examples],dtype=torch.long)
    return ids,lengths,labels
