"""Exact optimizer, RNG and sampler replay from real completed native states."""
import sys,json,random
from pathlib import Path
import torch
from safetensors.torch import load_file
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from reader import NeuralBytePointer
from data import pairs,batch_collate

def apply_from_checkpoint(arm,step):
    directory=ROOT/'checkpoints'/arm/f'step_{step:04d}'
    m=NeuralBytePointer(query_aware=arm=='query_aware')
    m.load_state_dict(load_file(str(directory/'model.safetensors')),strict=True)
    opt=torch.optim.AdamW(m.parameters(),lr=0.003,weight_decay=0.0001,foreach=False)
    # This pt file was produced locally in this experiment. Never unpickle untrusted checkpoints.
    state=torch.load(directory/'training_state.pt',weights_only=False)
    opt.load_state_dict(state['optimizer'])
    torch.set_rng_state(state['torch_rng']);random.setstate(state['python_random'])
    sampler=random.Random();sampler.setstate(state['sampler_state'])
    sampled=sampler.sample(range(8192),32)
    population=pairs(121203,8192)
    batch=[ex for i in sampled for ex in population[i]]
    ids,lengths,labels=batch_collate(batch)
    opt.zero_grad(set_to_none=True)
    loss=torch.nn.functional.cross_entropy(m(ids,lengths),labels)
    loss.backward()
    torch.nn.utils.clip_grad_norm_(m.parameters(),1.0)
    opt.step()
    return sampled,loss.item(),{k:p.detach().clone() for k,p in m.state_dict().items()}

def test_exact_native_state_replay():
    for arm in ('query_aware','query_blind_control'):
        a=apply_from_checkpoint(arm,1024)
        b=apply_from_checkpoint(arm,1024)
        assert a[0]==b[0] and a[1]==b[1]
        assert all(torch.equal(a[2][key],b[2][key]) for key in a[2])
