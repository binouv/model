import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
import pytest, torch
from data import pairs,batch_collate
from reader import NeuralBytePointer,predict_value

def test_bank_source_positions():
    for family in ['iid','long','unseen','wide']:
        for a,b in pairs(321,100,family):
            assert a.prompt[:-1]==b.prompt[:-1] and a.prompt[-1]!=b.prompt[-1]
            for x in [a,b]:
                raw=x.prompt.encode('ascii');assert raw[x.source_start:x.source_start+len(x.value)]==x.value.encode('ascii')
                assert raw[x.source_start-1]==ord('=')

def test_forward_gradient_and_no_label_at_inference():
    m=NeuralBytePointer();samples=[x for pair in pairs(33,5) for x in pair]
    ids,lengths,labels=batch_collate(samples)
    logits=m(ids,lengths)
    assert logits.shape==ids.shape
    assert torch.isfinite(logits[:,1:-2]).all()
    loss=torch.nn.functional.cross_entropy(logits,labels);loss.backward()
    assert m.structure[0].weight.grad.abs().sum().item()>0
    assert m.embedding.weight.grad.abs().sum().item()>0

def test_query_hidden_from_labels():
    a,b=pairs(991,1)[0]; assert a.value != '' and a.source_start != b.source_start
    model=NeuralBytePointer()
    pa=predict_value(model,a.prompt)
    pb=predict_value(model,b.prompt)
    assert isinstance(pa['source_start'],int) and isinstance(pb['source_start'],int)
    assert 'label' not in pa and 'gold' not in pa

def test_control_no_query_branch():
    m=NeuralBytePointer(query_aware=False)
    a,b=pairs(31,1)[0]
    ids,lengths,_=batch_collate([a,b])
    assert torch.equal(m(ids,lengths)[0],m(ids,lengths)[1])

def test_invalid_input_rejected():
    m=NeuralBytePointer()
    with pytest.raises(ValueError):predict_value(m,'a=2;b=3')
    with pytest.raises(ValueError):predict_value(m,'hi?☃')
