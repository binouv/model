import sys,json,random,torch,pytest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from train_eval import dataset,make_plan,serialize,metric_bootstrap,torch as ten,ROOT as rr
from tasks import tool_result,build_case

def test_training_and_held():
    train,held,reg=dataset()
    assert len(train)==4096 and len(held)==64 and len(reg)==32
    assert not {x['user'] for x in train}&{x['user'] for x in held}
    assert not {x['user'] for x in train}&{x['prompt'].split('Question: ')[-1].split('Вопрос: ')[-1] for x in reg}

def test_labels():
    from base.tokenizer import Tokenizer
    T=Tokenizer.load(ROOT.parent/'flygraph_l100ec_runtime/data/tokenizer.json')
    a,b=serialize(T,'User: Compute 1+2\nAssistant:','CALL ADD 1 2')
    assert (b!=-100).sum().item()>1 and int(a.max())<8192

def test_curriculum():
    p=make_plan();assert len(p)==512 and [x['step'] for x in p]==list(range(1,513))
    assert all(x['mode'] in ('call','final','replay') for x in p)
    assert len(set(x['index'] for x in p))>200

def test_memory_and_execution():
    x=build_case('last','ru',random.Random(1),unseen=True)
    assert tool_result('last',x['values'])==x['tool_result']
    with pytest.raises(ValueError):tool_result('bash',{})

def test_bootstrap():
    assert metric_bootstrap([False]*4,[True]*4,n=50)==[1.,1.]

