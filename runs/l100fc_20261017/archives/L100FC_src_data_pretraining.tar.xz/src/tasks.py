"""Finite, auditable agent tasks. Never execute generated Python/shell/network."""
from __future__ import annotations
import json,random,hashlib
from pathlib import Path

FAMILIES=('add','sum','last','trace')

def tool_result(family,values):
    if family=='add':return int(values['a'])+int(values['b'])
    if family=='sum':return sum(int(z) for z in values['xs'])
    if family=='last':
        matches=[int(v) for k,v in values['writes'] if k==values['key']]
        if not matches:raise ValueError('Missing memory key')
        return matches[-1]
    if family=='trace':
        x=int(values['x'])
        for y in values['deltas']:x+=int(y)
        return x
    raise ValueError('Unsupported tool')

def build_case(family,lang,rng,unseen=False):
    if family=='add':
        a,b=(rng.randint(131,210) if unseen else rng.randint(10,120) for _ in range(2))
        values={'a':a,'b':b}
        user=f'Вычисли {a} + {b}.' if lang=='ru' else f'Compute {a} + {b}.'
        call=f'CALL ADD {a} {b}'
    elif family=='sum':
        xs=[rng.randint(40,90) if unseen else rng.randint(3,35) for _ in range(rng.choice([2,3,4]))]
        values={'xs':xs}
        user=f'Сложи числа [{", ".join(map(str,xs))}].' if lang=='ru' else f'Sum [{", ".join(map(str,xs))}].'
        call='CALL SUM '+' '.join(map(str,xs))
    elif family=='last':
        keys=['a','b','c','d']
        writes=[(rng.choice(keys),rng.randint(100,180) if unseen else rng.randint(10,99)) for _ in range(rng.randint(5,8))]
        used=list(dict.fromkeys(k for k,_ in writes));key=rng.choice(used)
        values={'writes':writes,'key':key}
        seq='; '.join(f'{k}={v}' for k,v in writes)
        user=f'Записи по порядку: {seq}. Последнее значение {key}?' if lang=='ru' else f'Writes in time order: {seq}. Latest value of {key}?'
        call=f'CALL LAST {key}'
    else:
        x=rng.randint(120,170) if unseen else rng.randint(10,60)
        deltas=[rng.choice([-1,1])*rng.randint(2,19) for _ in range(rng.choice([2,3]))]
        values={'x':x,'deltas':deltas}
        seq='; '.join(('x+='+str(d) if d>=0 else 'x-='+str(-d)) for d in deltas)
        user=f'Программа: x={x}; {seq}. Чему равен x?' if lang=='ru' else f'Program: x={x}; {seq}. Find x.'
        call='CALL TRACE '+str(x)+' '+' '.join(f'{d:+d}' for d in deltas)
    result=tool_result(family,values)
    prefix=('Пользователь: ' if lang=='ru' else 'User: ')+user+('\nАссистент:' if lang=='ru' else '\nAssistant:')
    # Explicit bounded tool output. During evaluation FINAL uses the SAME gold tool result, never predicted one.
    final_prefix=prefix+' '+call+('\nИнструмент: ' if lang=='ru' else '\nTool: ')+str(result)+('\nАссистент:' if lang=='ru' else '\nAssistant:')
    return {'family':family,'lang':lang,'user':user,'call_prompt':prefix,'call':call,'final_prompt':final_prefix,'final':f'FINAL {result}', 'tool_result':result,'values':values}

def make_datasets(out,train_n=512,held_n=32,seed_train=17102026,seed_held=17102027):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    rng=random.Random(seed_train);train=[];seen=set()
    for i in range(train_n):
        family=FAMILIES[i%4];lang='ru' if (i//4)%2 else 'en'
        for _ in range(5000):
            candidate=build_case(family,lang,rng,unseen=False)
            if candidate['user'] not in seen:
                train.append(candidate);seen.add(candidate['user']);break
        else:raise RuntimeError('Generator has insufficient unique train cases')
    rng=random.Random(seed_held);held=[]
    for i in range(held_n):
        family=FAMILIES[i%4];lang='ru' if (i//4)%2 else 'en'
        for _ in range(5000):
            candidate=build_case(family,lang,rng,unseen=True)
            if candidate['user'] not in seen:
                held.append(candidate);seen.add(candidate['user']);break
        else:raise RuntimeError('Generator has insufficient unique held cases')
    # Compare canonical prompt text, not just random seeds, and prevent repeated individual task IDs.
    assert len(set(z['user'] for z in train))==len(train)
    assert len(set(z['user'] for z in held))==len(held)
    assert not (set(z['user'] for z in train)&set(z['user'] for z in held))
    for name,rows in [('train.jsonl',train),('held.jsonl',held)]:
        with (out/name).open('w',encoding='utf8') as f:
            for row in rows:f.write(json.dumps(row,ensure_ascii=False,sort_keys=True)+'\n')
    return train,held

def read_jsonl(path):
    with open(path,encoding='utf8') as f:return [json.loads(x) for x in f if x.strip()]

def checksum(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()
