"""L100FC full-dense 100M, reproducible finite stage; native Adafactor continuation."""
from __future__ import annotations
import json, hashlib, math, os, random, sys, time, argparse, zipfile
from pathlib import Path
import torch
from safetensors.torch import save_file, load_file

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'src';sys.path.insert(0,str(SRC))
PREV=ROOT.parent/'l100fb'
PARENT=ROOT.parent/'flygraph_l100ec_runtime'
sys.path.insert(0,str(PARENT))
from base.model import Config,Model
from base.tokenizer import Tokenizer
from tasks import make_datasets,read_jsonl,tool_result,checksum,build_case
SEED=17102110
PARENT_SHA='bd69ad4dbd392ac506ed89d2d35b413c72c12151eec987b07a5a23193ede0492'
OPT_SHA='901238ee4cfa5f1fcfa8cf80371f7969385628c1cd0ba58f6effa2650f15949e'
N_UPDATES=512


def dump_json(obj,path):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,sort_keys=True,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    os.replace(tmp,p)


def dataset():
    data=ROOT/'data';data.mkdir(exist_ok=True)
    if not (data/'train.jsonl').exists():
        train,held=make_datasets(data,train_n=4096,held_n=64,seed_train=SEED,seed_held=17102111)
        reg_rng=random.Random(17102112);reg=[]
        seen={z['user'] for z in train+held}
        for i in range(32):
            for _ in range(2000):
                family=('add','sum','last','trace')[i%4]
                lang='ru' if (i//4)%2 else 'en'
                t=build_case(family,lang,reg_rng,unseen=True)
                if t['user'] not in seen:
                    seen.add(t['user'])
                    reg.append({'family':family,'lang':lang,'prompt':('Вопрос: ' if lang=='ru' else 'Question: ')+t['user']+('\nОтвет:' if lang=='ru' else '\nAnswer:'),'answer':'F='+str(t['tool_result'])});break
            else:raise RuntimeError('No disjoint regression case')
        with (data/'regression.jsonl').open('w',encoding='utf8') as fp:
            for item in reg:fp.write(json.dumps(item,ensure_ascii=False,sort_keys=True)+'\n')
    train=read_jsonl(data/'train.jsonl');held=read_jsonl(data/'held.jsonl');reg=read_jsonl(data/'regression.jsonl')
    assert len(train)==4096 and len(held)==64 and len(reg)==32
    seen={x['user'] for x in train};held_u={x['user'] for x in held}
    assert len(seen)==4096 and len(held_u)==64 and not(seen&held_u)
    assert not ({z['prompt'].split('Question: ')[-1].split('Вопрос: ')[-1] for z in reg}&seen)
    return train,held,reg


def make_plan():
    path=ROOT/'data'/'schedule.json'
    if path.exists():
        p=json.loads(path.read_text());assert len(p)==N_UPDATES;return p
    rr=random.Random(SEED+1);rows=[]
    for i in range(N_UPDATES):
        if i<160:
            mode=rr.choices(('call','final','replay'),weights=(60,30,10))[0]
        else:mode=rr.choices(('call','final','replay'),weights=(45,45,10))[0]
        # 8-stratum family/language balance; choose fresh independent index per stratum
        stratum=i%8;family=stratum%4;lang='en' if stratum//4==0 else 'ru'
        available=[j for j in range(family,4096,4) if ((j//4)%2==0)==(lang=='en')]
        idx=rr.choice(available)
        rows.append({'step':i+1,'mode':mode,'index':idx,'lang':lang,'family':('add','sum','last','trace')[family]})
    dump_json(rows,path)
    return rows


def prior_replay():
    archive='/mnt/data/FlyGraph_L100A_Release/FlyGraph_L100A_Source_Data_Results.zip'
    with zipfile.ZipFile(archive) as z:
        return [json.loads(x) for x in z.read('runs/l100a_20261011/data/train_replay.jsonl').splitlines()]


def model_opt_from_previous():
    torch.set_num_threads(4)
    torch.manual_seed(17102026)
    cfg=json.loads((PARENT/'models/curriculum/config.json').read_text())
    model=Model(Config(**cfg));model.config.checkpoint_blocks=True
    ck=PREV/'checkpoints/step_0128'
    assert checksum(ck/'model.safetensors')==PARENT_SHA
    assert checksum(ck/'training_state.pt')==OPT_SHA
    checkpoint=json.loads((ck/'MANIFEST.json').read_text())
    assert checkpoint['step']==128
    model.load_state_dict(load_file(str(ck/'model.safetensors')),strict=True)
    assert sum(z.numel() for z in model.parameters())==100028328
    optimizer=torch.optim.Adafactor(model.parameters(),lr=.00012,weight_decay=.01)
    state=torch.load(ck/'training_state.pt',map_location='cpu',weights_only=True)
    optimizer.load_state_dict(state['optimizer'])
    assert state['step']==128 and state['sampler_pos']==128
    torch.set_rng_state(state['torch_rng'])
    random.setstate(state['python_rng'])
    return model,optimizer


def serialize(tok,prompt,target):
    p=tok.encode(prompt,bos=True)
    a=tok.encode(' '+target,eos=True)
    arr=p+a
    ids=torch.tensor(arr[:-1],dtype=torch.long)[None]
    lab=torch.tensor(arr[1:],dtype=torch.long)[None]
    lab[:,:len(p)-1]=-100
    assert int(ids.max())<8192 and ids.numel()<2048
    return ids,lab


def native_checkpoint(step,m,opt,datafiles,seconds):
    out=ROOT/'checkpoints'/f'step_{step:04d}'
    if out.exists():raise FileExistsError(out)
    temp=ROOT/'checkpoints'/f'.step_{step:04d}.pending'
    temp.mkdir(parents=True,exist_ok=False)
    wt={k:v.detach().cpu().contiguous() for k,v in m.state_dict().items()}
    save_file(wt,str(temp/'model.safetensors'))
    identity={x.name:checksum(x) for x in datafiles}
    payload={'stage_step':step,'total_optimizer_updates':128+step,'optimizer':opt.state_dict(),
             'torch_rng':torch.get_rng_state(),'python_rng':random.getstate(),
             'sampler_cursor':step,'schedule_sha256':identity['schedule.json'],
             'data_sha256':identity,'run_id':'L100FC_20261017','model_parent_sha256':PARENT_SHA}
    torch.save(payload,temp/'training_state.pt')
    check={'experiment':'L100FC_20261017','status':'in_progress' if step<512 else 'trained_awaiting_evaluation',
           'stage_step':step,'total_updates':128+step,'model_params':100028328,'parent_sha256':PARENT_SHA,
           'elapsed_s':seconds,'data_sha256':identity,
           'files':{x:{'bytes':(temp/x).stat().st_size,'sha256':checksum(temp/x)} for x in ('model.safetensors','training_state.pt')}}
    dump_json(check,temp/'MANIFEST.json')
    assert len(load_file(str(temp/'model.safetensors')))==len(wt)
    back=torch.load(temp/'training_state.pt',map_location='cpu',weights_only=True)
    assert back['stage_step']==step and back['sampler_cursor']==step
    os.replace(temp,out)
    return check


def train():
    start=time.time();torch.set_num_threads(4)
    train,held,reg=dataset();schedule=make_plan();replay=prior_replay()
    files=[ROOT/'data'/x for x in ('train.jsonl','held.jsonl','regression.jsonl','schedule.json')]
    cfg={'new_steps':N_UPDATES,'source_step':128,'seed':SEED,'batch':1,'optimizer':'Adafactor',
         'lr_start':.00035,'lr_final':.00012,'precision':'bf16 CPU compute; fp32 delta',
         'parent_SHA':PARENT_SHA,'optimizer_SHA':OPT_SHA,'checkpoint_every':64,
         'data_sha256':{x.name:checksum(x) for x in files}}
    dump_json(cfg,ROOT/'configs.json')
    m,opt=model_opt_from_previous();tok=Tokenizer.load(PARENT/'data/tokenizer.json')
    logs=[];m.train()
    for item in schedule:
        i=item['step'];t=train[item['index']]
        if item['mode']=='call':prompt,target=t['call_prompt'],t['call']
        elif item['mode']=='final':prompt,target=t['final_prompt'],t['final']
        else:
            old=replay[(item['index']*17+i*13)%len(replay)]
            prompt,target=old['prompt'],'F='+str(old['answer'])
        ids,labels=serialize(tok,prompt,target)
        lr=.00035+(.00012-.00035)*(i-1)/(N_UPDATES-1)
        for g in opt.param_groups:g['lr']=lr
        opt.zero_grad(set_to_none=True)
        with torch.autocast('cpu',dtype=torch.bfloat16):loss=m(ids,targets=labels)
        if not torch.isfinite(loss):raise RuntimeError('Non-finite loss')
        loss.backward()
        gn=torch.nn.utils.clip_grad_norm_(m.parameters(),1.)
        if not torch.isfinite(gn):raise RuntimeError('Non-finite gradient')
        opt.step()
        logs.append({'step':i,'parent_total_step':i+128,'kind':item['mode'],'loss':float(loss.item()),
                     'grad_norm':float(gn.item()),'lr':lr,'example_index':item['index'],'seconds':time.time()-start})
        if i%8==0:
            print('TRAIN',i,'loss',round(float(loss),4),'lr',round(lr,6),'elapsed_s',round(time.time()-start,1),flush=True)
            dump_json({'status':'in_progress','complete_steps':i,'latest_loss':float(loss)},ROOT/'metrics/progress.json')
        if i%64==0:
            check=native_checkpoint(i,m,opt,files,time.time()-start)
            dump_json({'run':'L100FC','status':'in_progress' if i<N_UPDATES else 'trained_awaiting_eval',
                       'completed_updates':i,'complete_total_steps':128+i,'checkpoint_sha256':check['files']['model.safetensors']['sha256']},ROOT/'metrics/checkpoint_status.json')
            dump_json({'config':cfg,'losses':logs,'completed_updates':i,'status':'in_progress' if i<N_UPDATES else 'trained_awaiting_eval'},ROOT/'metrics/train.json')
            print('CHECKPOINT',i,check['files']['model.safetensors']['sha256'],flush=True)
    print('TRAIN_COMPLETE',round(time.time()-start,1),flush=True)


def predict(model,tok,prompt,max_new_tokens=48):
    ids=torch.tensor(tok.encode(prompt,bos=True),dtype=torch.long)[None]
    with torch.inference_mode(),torch.autocast('cpu',dtype=torch.bfloat16):
        outputs=model.generate(ids,max_new_tokens=max_new_tokens,eos_id=tok.EOS)[0].tolist()
    return {'text':tok.decode(outputs),'tokens':outputs,'eos':bool(outputs and outputs[-1]==tok.EOS), 'num_tokens':len(outputs)}


def metric_bootstrap(before,after,n=10000):
    rng=random.Random(17102113);v=[];dif=[int(y)-int(x) for x,y in zip(before,after)]
    for i in range(n):v.append(sum(rng.choice(dif) for _ in dif)/len(dif))
    v.sort();return [v[int(.025*(n-1))],v[int(.975*(n-1))]]


def evaluate():
    torch.set_num_threads(4);st=time.time()
    _,held,reg=dataset();tok=Tokenizer.load(PARENT/'data/tokenizer.json')
    assert len(held)==64 and len(reg)==32
    result={}
    for arm in ('pre','post'):
        m=Model(Config(**json.loads((PARENT/'models/curriculum/config.json').read_text())))
        path=(PREV/'checkpoints/step_0128/model.safetensors') if arm=='pre' else (ROOT/'checkpoints/step_0512/model.safetensors')
        assert checksum(path)==(PARENT_SHA if arm=='pre' else json.loads((ROOT/'checkpoints/step_0512/MANIFEST.json').read_text())['files']['model.safetensors']['sha256'])
        m.load_state_dict(load_file(str(path)),strict=True);m.eval();m.config.checkpoint_blocks=False
        agent=[];reg_rows=[]
        for i,task in enumerate(held):
            call=predict(m,tok,task['call_prompt']);fin=predict(m,tok,task['final_prompt'])
            call_valid=call['text'].strip().startswith('CALL ')
            exact_call=call['eos'] and call['text'].strip()==task['call']
            exact_final=fin['eos'] and fin['text'].strip()==task['final']
            agent.append({'i':i,'family':task['family'],'lang':task['lang'],
                          'expected_call':task['call'],'expected_final':task['final'],
                          'call':call,'final':fin,'call_schema':call_valid,
                          'call_correct':exact_call,'final_correct':exact_final,'e2e':exact_call and exact_final})
            if (i+1)%16==0:print('EVAL',arm,i+1,'elapsed_s',round(time.time()-st,1),flush=True)
        for i,task in enumerate(reg):
            pred=predict(m,tok,task['prompt'])
            reg_rows.append({'i':i,'family':task['family'],'expected':task['answer'], 'prompt':task['prompt'],
                             'pred':pred,'correct':pred['eos'] and pred['text'].strip()==task['answer']})
        result[arm]={'agent':agent,'regression':reg_rows}
        dump_json(result[arm],ROOT/'metrics'/f'{arm}_raw_predictions.json')
        del m
    out={'run':'L100FC_20261017','status':'completed_fixed_evaluation','trained_new_steps':512,
         'trained_total_steps':640,'reference_Qwen_run':False,'reference_MiniCPM_run':False,
         'superiority_Qwen':False,'superiority_MiniCPM_V':False,'parent_sha256':PARENT_SHA,
         'child_sha256':checksum(ROOT/'checkpoints/step_0512/model.safetensors'), 'by_arm':{},
         'elapsed_eval_seconds':time.time()-st}
    for arm,rows in result.items():
        a=rows['agent'];r=rows['regression']
        out['by_arm'][arm]={'agent_n':len(a),'exact_call':sum(x['call_correct'] for x in a),
                           'valid_call_prefix':sum(x['call_schema'] for x in a),
                           'exact_final':sum(x['final_correct'] for x in a),'e2e':sum(x['e2e'] for x in a),
                           'regression_n':len(r),'regression_correct':sum(x['correct'] for x in r),
                           'by_family':{f:{'count':sum(z['family']==f for z in a),
                                           'exact_call':sum(z['call_correct'] for z in a if z['family']==f),
                                           'e2e':sum(z['e2e'] for z in a if z['family']==f)} for f in ('add','sum','last','trace')}}
    pre=result['pre']['agent'];post=result['post']['agent'];d=metric_bootstrap([x['e2e'] for x in pre],[x['e2e'] for x in post])
    gain=(out['by_arm']['post']['e2e']-out['by_arm']['pre']['e2e'])/64
    reg_loss=(out['by_arm']['pre']['regression_correct']-out['by_arm']['post']['regression_correct'])/32
    out['paired']={'e2e_gain_pp':gain*100,'bootstrap95_pp':[v*100 for v in d],
                   'regression_loss_pp':reg_loss*100,'preregistered_gate_passed':gain>=.10 and reg_loss<=.02}
    dump_json(out,ROOT/'metrics/summary.json');print('SUMMARY',json.dumps(out,ensure_ascii=False),flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('command',choices=('generate','train','evaluate'))
    a=p.parse_args()
    if a.command=='generate':dataset();make_plan();print('DATA_GENERATED')
    if a.command=='train':train()
    if a.command=='evaluate':evaluate()
if __name__=='__main__':main()
